#ifndef FICHEIROS_H
#define FICHEIROS_H

//NOME DOS DOCUMENTOS
#define FILENAME_USERS "PROGRAMA\\USERS\\users.bin"
#define FILENAME_SALARIOS "PROGRAMA\\SALARIOS\\salarios.bin"
#define FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES "PROGRAMA\\TABELAS_RETENCAO_IRS\\DEPENDENTE_CASADO_DOIS_TITULARES_bin"
#define FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR "PROGRAMA\\TABELAS_RETENCAO_IRS\\DEPENDENTE_CASADO_UNICO_TITULAR_bin"
#define FILENAME_DEPENDENTE_NAO_CASADO "PROGRAMA\\TABELAS_RETENCAO_IRS\\DEPENDENTE_NAO_CASADO_bin"
#define FILENAME_SS "PROGRAMA\\SEGURANCA_SOCIAL\\TAXAS.txt"
#define FILENAME_LOG "LOGS\\logs.bin"
#define FILENAME_USERS_DOC "UTILIZADOR\\FUNCIONARIOS\\funcionarios.txt"
#define FILENAME_SALARIOS_DOC "UTILIZADOR\\SALARIOS\\salarios.txt"

//TIPO DE FORMATO DE LEITURA OU ESCRITA
#define FORMATO_LOGS "DIA: %d-%02d-%02d HORA: %02d:%02d:%02d | %s\n"
#define FORMATO_USERS "%d %[^ ] %ld %d %d %d %d %f %f %d %d %d %d %d %d %d %d %d %d "
#define FORMATO_SALARIOS "%d %d %d %d %d %d %d"
#define FORMATO_SS "%f %f %f %f"
#define FORMATO_TABELA "%d %f %f %f %f %f %f"

//TIPO DE FORMATO PARA MOSTRAR O QUE FOI GUARDADO
#define FORMATO_MOSTRAR_SALARIOS "| Codigo: %d | Ano: %d | Mes: %d | Dias Completos: %d | Meios dias: %d | Fins de semana %d | Faltas: %d  \n"
#define FORMATO_MOSTRAR_USERS "\n+ FUNCIONARIO +\n| Codigo: %d \n| Nome: %s \n| Numero de telemovel: %ld \n| Estado civil: %d \n| Numero de titulares: %d \n| Numero de filhos: %d \n| Cargo: %d \n| Valor hora: %f \n| Subsidio de alimentação: %f \n| Data de nascimento: %d-%d-%d \n| Data de entrada na empresa: %d-%d-%d \n| Data de saida da empresa: %d-%d-%d\n"
#define FORMATO_CRITERIOS "| 1) Geral entidade patronal: %0.2f \n| 2) Geral Trabalhador: %0.2f \n| 3) Chefia entidade patronal: %0.2f \n| 4) Chefia trabalhador: %0.2f \n| 0) Sair \n"
#define FORMATO_MOSTRAR_CRITERIOS "| Geral entidade patronal: %0.2f \n| Geral Trabalhador: %0.2f \n| Chefia entidade patronal: %0.2f \n| Chefia trabalhador: %0.2f \n"
#define FORMATO_MOSTRAR_TABELAS "| %d %0.2f %0.2f %0.2f %0.2f %0.2f %0.2f \n"
#define FORMATO_MENU_ALTERAR_IRS "| 1) Tabela dois titulares \n| 2) Tabela unico titular \n| 3) Tabela nao casado \n| 0) sair \n| Digite a tabela que deseja alterar: "

//MENSAGENS
#define VENCIMENTO_ERRO "| !Vencimento incorreto!"
#define ERRO_FILE "| !Ficheiro não encontrado! "
#define SUCESSO_FILE "| Ficheiro aberto com sucesso"
#define PERGUNTA_INFO_GUARDADA "| Deseja ver a informação guardada [s/n]? "
#define SUCESSO_IRS "| Alteração feita com sucesso"
#define ERRO_MEMORIA "| Problemas na memoria "
//TADELAS IRS

//DEPENDENTE_CASADO_DOIS_TITULARES
typedef struct {
    float filho_zero, filho_um, filho_dois, filho_tres, filho_quatro, filho_cinco;
    int vencimento;
} Dois_titulares;

typedef struct{
    int contador;
    Dois_titulares *Dois_titulares_array;
} ListaUm;

//DEPENDENTE_CASADO_UNICO_TITULARES
typedef struct {
    float filho_zero, filho_um, filho_dois, filho_tres, filho_quatro, filho_cinco;
    int vencimento;
} Unico_titular;

typedef struct{
    int contador;
    Unico_titular *Unico_titular_array;
} ListaDois;

//DEPENDENTE_NAO_CASADO
typedef struct {
    float filho_zero, filho_um, filho_dois, filho_tres, filho_quatro, filho_cinco;
    int vencimento;
} Nao_casado;

typedef struct{
    int contador;
    Nao_casado *Nao_casado_array;
} ListaTres;

typedef struct {
    float geral_empregadora, geral_trabalhador, admin_empregadora, admin_trabalhador;
} Taxas;

//FUNÇÕES
int importar_users_sys(Empresa *funcionarios); 
int importar_salarios_sys(Lista_calc *conta); 
void importar_users_doc(Empresa *arrayRH);
void importar_salarios_doc(Lista_calc *conta);
void guardar(Empresa *funcionarios, Lista_calc *conta, ListaUm *lista_um, ListaDois *lista_dois, ListaTres *lista_tres, Taxas *taxa); 
void importarTabela_um(ListaUm *array_um);
void importarTabela_dois(ListaDois *array_dois);
void importarTabela_tres(ListaTres *array_tres);
void importarTablelaSS(Taxas *taxa);
void logs(char *mensagem);
void alterarCriterioSS(Taxas *taxa);
void mostrarTaxas(Taxas *taxa);
void mostratTabelas(ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres);
void alterarCriterioIRS(ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado);
int verificarVencimento(int tabela, int vencimento, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado);
#endif /* FICHEIROS_H */

