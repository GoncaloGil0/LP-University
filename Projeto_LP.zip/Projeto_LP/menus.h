#ifndef MENUS_H
#define MENUS_H

#include "ficheiros.h"
#include "pedir_info.h"

#define FORMATO_MOSTRAR_TODOS_USERS "\n+ FUNCIONARIO +\n| Codigo: %d \n| Nome: %s \n| Numero de telemovel: %ld \n| Estado civil: %s \n| Numero de titulares: %d \n| Numero de filhos: %d \n| Cargo: %s \n| Valor hora: %f \n| Subsidio de alimentação: %f \n| Data de nascimento: %d-%d-%d \n| Data de entrada na empresa: %d-%d-%d \n| Data de saida da empresa: %d-%d-%d\n"
#define FORMATO_MOSTRAR_TODOS_SALARIOS "\n| %d | %d | %d | %d | %d | %d | %d"

//FUNÇOES

//MENUS
void menu(Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres );
void menu_calc_salarial ( Lista_calc *conta , Empresa *arrayRH);
void menu_tipo_add_funcionarios( Empresa *arrayRH );
void menu_gestao_funcionarios(Empresa *arrayRH);
void menu_gestao_tabelas_IRS();
void menu_gestao_SS(Taxas *taxa );
void menu_listagens();

//MOSTRAR
void mostrarUsers(Empresa *arrayRH);
void mostrarSalarios(Lista_calc *conta);

#endif
