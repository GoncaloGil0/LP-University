#include <stdio.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "ficheiros.h"
#include "menus.h"

//IMPORTAR USERS DOCUMENTO DO SISTEMA
int importar_users_sys(Empresa *arrayRH) {
    int n = 0;
    Funcionario *temp;
    FILE *ficheiro_users = fopen(FILENAME_USERS, "rb");
    if (ficheiro_users == NULL) {
        return (0);
    }
    
    do {
        
        temp = (Funcionario*) realloc(arrayRH->funcionarios_array, arrayRH->contador * sizeof (Funcionario) + sizeof (Funcionario));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        arrayRH->funcionarios_array = temp;
        
        temp = NULL;
        free(temp);
        
        fread(&arrayRH->funcionarios_array[arrayRH->contador], sizeof (Funcionario), 1, ficheiro_users);
        arrayRH->contador++;
        n++;
    } while (!feof(ficheiro_users));
    
    fclose(ficheiro_users);
    return (n);
}

//IMPORTAR SALARIOS DOCUMENTO DO SISTEMA
int importar_salarios_sys(Lista_calc *conta) {
    int n;
    Conta *temp;
    FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS, "rb");
    if (ficheiro_salarios == NULL) {
        return (0);
    }
    do {
        temp = (Conta*) realloc(conta->calculo_array, conta->contador * sizeof (Conta) + sizeof (Conta));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        conta->calculo_array = temp;
        temp = NULL;
        free(temp);
        fread(&conta->calculo_array[conta->contador], sizeof (Conta), 1, ficheiro_salarios);
        conta->contador++;
        n++;
    } while (!feof(ficheiro_salarios));
    fclose(ficheiro_salarios);
    return (n);
}

//IMPORTAR USERS DOCUMENTO DO UTILIZADOR
void importar_users_doc(Empresa *arrayRH) {
    int n = 0;
    char buffer[250], resposta;
    Funcionario *temp;

    FILE *ficheiro_users = fopen(FILENAME_USERS_DOC, "r");
    if (ficheiro_users == NULL) {
        puts(ERRO_FILE);
    }

    do {
        fgets(buffer, sizeof (buffer), ficheiro_users);
        temp = (Funcionario*) realloc(arrayRH->funcionarios_array, arrayRH->contador * sizeof (Funcionario) + sizeof (Funcionario));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        arrayRH->funcionarios_array = temp;
        temp = NULL;
        free(temp);
        sscanf(buffer, FORMATO_USERS, &arrayRH->funcionarios_array[arrayRH->contador].codigo,
                arrayRH->funcionarios_array[arrayRH->contador].nome,
                &arrayRH->funcionarios_array[arrayRH->contador].numero_tlm,
                &arrayRH->funcionarios_array[arrayRH->contador].est_civil,
                &arrayRH->funcionarios_array[arrayRH->contador].titulares,
                &arrayRH->funcionarios_array[arrayRH->contador].numero_filhos,
                &arrayRH->funcionarios_array[arrayRH->contador].cargo,
                &arrayRH->funcionarios_array[arrayRH->contador].valor_hora,
                &arrayRH->funcionarios_array[arrayRH->contador].valor_sub_ali,
                &arrayRH->funcionarios_array[arrayRH->contador].nascimento.dia,
                &arrayRH->funcionarios_array[arrayRH->contador].nascimento.mes,
                &arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano,
                &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.dia,
                &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.mes,
                &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano,
                &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.dia,
                &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.mes,
                &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.ano,
                &arrayRH->funcionarios_array[arrayRH->contador].ativo);
        arrayRH->contador++;
        n++;
    } while (!feof(ficheiro_users));

    fclose(ficheiro_users);

    printf("|\n| Foram adicionados %d funcionarios \n", n);

    do {
        printf(PERGUNTA_INFO_GUARDADA);
        scanf(" %c", &resposta);
    } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');

    if (resposta == 'S' || resposta == 's') {

        for (int i = 0; i < n; i++) {
            printf(FORMATO_MOSTRAR_USERS, arrayRH->funcionarios_array[(arrayRH->contador - n) + i].codigo,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nome,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].numero_tlm,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].est_civil,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].titulares,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].numero_filhos,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].cargo,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].valor_hora,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].valor_sub_ali,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nascimento.dia,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nascimento.mes,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nascimento.ano,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].entrada_emp.dia,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].entrada_emp.mes,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].entrada_emp.ano,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].saida_emp.dia,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].saida_emp.mes,
                    arrayRH->funcionarios_array[(arrayRH->contador - n) + i].saida_emp.ano);
        }
    }
}

//IMPORTAR SALARIOS DOCUMENTO DO UTILIZADOR
void importar_salarios_doc(Lista_calc *conta) {

    // da exit sem ler POR CORRIGIR
    int n = 0;
    char buffer[250], resposta;
    Conta *temp;

    FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS_DOC, "r");
    if (ficheiro_salarios == NULL) {
        puts(ERRO_FILE);
    }
    do {
        fgets(buffer, sizeof (buffer), ficheiro_salarios);
        temp = (Conta*) realloc(conta->calculo_array, conta->contador * sizeof (Conta) + sizeof (Conta));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        conta->calculo_array = temp;
        temp = NULL;
        free(temp);
        sscanf(buffer, FORMATO_SALARIOS, &conta->calculo_array[conta->contador].codigo,
                &conta->calculo_array[conta->contador].ano,
                &conta->calculo_array[conta->contador].mes,
                &conta->calculo_array[conta->contador].dias_compl,
                &conta->calculo_array[conta->contador].dias_meios,
                &conta->calculo_array[conta->contador].dias_fds,
                &conta->calculo_array[conta->contador].dias_faltas);
        (conta->contador)++;
        n++;
    } while (!feof(ficheiro_salarios));

    fclose(ficheiro_salarios);

    printf("|\n| Foram adicionados %d salarios \n", n);

    do {
        printf(PERGUNTA_INFO_GUARDADA);
        scanf(" %c", &resposta);
    } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');

    if (resposta == 'S' || resposta == 's') {

        for (int i = 0; i < n; i++) {
            printf(FORMATO_MOSTRAR_SALARIOS, conta->calculo_array[i].codigo,
                    conta->calculo_array[i].ano,
                    conta->calculo_array[i].mes,
                    conta->calculo_array[i].dias_compl,
                    conta->calculo_array[i].dias_meios,
                    conta->calculo_array[i].dias_fds,
                    conta->calculo_array[i].dias_faltas);
        }
    }
}

//IMPORTAR TABELA DE IRS DOIS TITULARES
void importarTabela_um(ListaUm *array_um) {
    
    Dois_titulares *temp;
    FILE *ficheiro_dois_titulares = fopen(FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES, "rb");
    if (ficheiro_dois_titulares == NULL) {
        puts(ERRO_FILE);
    }
    do {
        temp = (Dois_titulares*) realloc(array_um->Dois_titulares_array, array_um->contador * sizeof (Dois_titulares) + sizeof (Dois_titulares));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        array_um->Dois_titulares_array = temp;
        temp = NULL;
        free(temp);
        fread(&array_um->Dois_titulares_array[array_um->contador], sizeof (Dois_titulares), 1, ficheiro_dois_titulares);
        array_um->contador++;
    } while (!feof(ficheiro_dois_titulares));
    fclose(ficheiro_dois_titulares);
    puts("Importada");
}

//IMPORTAR TABELA DE IRS UM TITULAR
void importarTabela_dois(ListaDois *array_dois) {

    Unico_titular *temp;
    FILE *ficheiro_unico_titular = fopen(FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR, "rb");
    if (ficheiro_unico_titular == NULL) {
        puts(ERRO_FILE);
    }
    do {
        temp = (Unico_titular*) realloc(array_dois->Unico_titular_array, array_dois->contador * sizeof (Unico_titular) + sizeof (Unico_titular));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        array_dois->Unico_titular_array = temp;
        temp = NULL;
        free(temp);
        fread(&array_dois->Unico_titular_array[array_dois->contador], sizeof (Unico_titular), 1, ficheiro_unico_titular);
        array_dois->contador++;
    } while (!feof(ficheiro_unico_titular));
    fclose(ficheiro_unico_titular);
    puts("Importada");
}

//IMPORTAR TABELA DE IRS NAO CASADO
void importarTabela_tres(ListaTres *array_tres) {

    Nao_casado *temp;
    FILE *ficheiro_nao_casado = fopen(FILENAME_DEPENDENTE_NAO_CASADO, "rb");
    if (ficheiro_nao_casado == NULL) {
        puts(ERRO_FILE);
    }
    do {
        temp = (Nao_casado*) realloc(array_tres->Nao_casado_array, array_tres->contador * sizeof (Nao_casado) + sizeof (Nao_casado));
        if (temp == NULL) {
            puts(ERRO_MEMORIA);
        }
        array_tres->Nao_casado_array = temp;
        temp = NULL;
        free(temp);
        fread(&array_tres->Nao_casado_array[array_tres->contador], sizeof (Nao_casado), 1, ficheiro_nao_casado);
        array_tres->contador++;
    } while (!feof(ficheiro_nao_casado));
    fclose(ficheiro_nao_casado);
    puts("Importada");
}

//IMPORTAR TABELA SS
void importarTablelaSS(Taxas *taxa){  
    char buffer[256];
    
    FILE *file = fopen(FILENAME_SS, "r");
    
    if (file == NULL) {     
        puts(ERRO_FILE);
    }

    fgets(buffer, sizeof(buffer), file);
    sscanf(buffer, FORMATO_SS, &taxa->geral_empregadora, &taxa->geral_trabalhador, &taxa->admin_empregadora, &taxa->admin_trabalhador);           
        
    fclose(file);  
    
    printf("Importada");
}

//GUARDAR TODOS OS DADOS EM MEMORIA
void guardar(Empresa *funcionarios, Lista_calc *conta, ListaUm *lista_um, ListaDois *lista_dois, ListaTres *lista_tres, Taxas *taxa) {
    
    printf("+ GUARDAR INFORMAÇÃO + \n");
    
    //GUARDAR TODOS OS USERS
    FILE *ficheiro_users = fopen(FILENAME_USERS, "wb");
    if (ficheiro_users == NULL) {
        puts(ERRO_FILE);
    }

    for (int i = 0; i < funcionarios->contador; i++) {
        fwrite(&funcionarios->funcionarios_array[i], sizeof (Funcionario), 1, ficheiro_users);
    }

    fclose(ficheiro_users);
    printf("| Funcionarios: Guardado \n");

    //GUARDAR TODOS OS DADOS PARA O CALC DO SALARIO
    FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS, "wb");
    if (ficheiro_salarios == NULL) {
        puts(ERRO_FILE);
    }

    for (int i = 0; i < conta->contador; i++) {
        fwrite(&conta->calculo_array[i], sizeof (Conta), 1, ficheiro_salarios);
    }

    fclose(ficheiro_salarios);
    printf("| Salarios: Guardado \n");

    //GUARDAR TABELA DE DOIS TITULARES
    FILE *ficheiro_dois_titulares = fopen(FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES, "wb");
    if (ficheiro_dois_titulares == NULL) {
        puts(ERRO_FILE);
    }

    for (int i = 0; i < lista_um->contador; i++) {
        fwrite(&lista_um->Dois_titulares_array[i], sizeof (Dois_titulares), 1, ficheiro_dois_titulares);
    }

    fclose(ficheiro_dois_titulares);
    printf("| Tabela IRS 1: Guardado \n");

    //GUARDAR TABELA DE UNICO TITULAR
    FILE *ficheiro_um_titular = fopen(FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR, "wb");
    if (ficheiro_um_titular == NULL) {
        puts(ERRO_FILE);
    }

    for (int x = 0; x < lista_dois->contador; x++) {
        fwrite(&lista_dois->Unico_titular_array[x], sizeof (Unico_titular), 1, ficheiro_um_titular);
    }

    fclose(ficheiro_um_titular);
    printf("| Tabela IRS 2: Guardado \n");

    //GUARDAR TABELA DE NAO CASADO
    FILE *ficheiro_nao_casado = fopen(FILENAME_DEPENDENTE_NAO_CASADO, "wb");
    if (ficheiro_nao_casado == NULL) {
        puts(ERRO_FILE);
    }

    for (int y = 0; y < lista_tres->contador; y++) {
        fwrite(&lista_tres->Nao_casado_array[y], sizeof (Nao_casado), 1, ficheiro_nao_casado);
    }

    fclose(ficheiro_nao_casado);
    printf("| Tabela IRS 3: Guardado \n");
    
    FILE *ficheiro_SS = fopen(FILENAME_SS, "w");
    if (ficheiro_SS == NULL) {
        puts(ERRO_FILE);
    }

    fprintf(ficheiro_SS, FORMATO_SS, taxa->geral_empregadora, taxa->geral_trabalhador, taxa->admin_empregadora, taxa->admin_trabalhador);

    fclose(ficheiro_SS);
    printf("| Tabela SS: Guardado \n");
    
}

//ALTERAR CRITERIO SS
void alterarCriterioSS(Taxas *taxa){
    int opcao;  
    float valor;
    
    printf(FORMATO_CRITERIOS, taxa->geral_empregadora, taxa->geral_trabalhador, taxa->admin_empregadora, taxa->admin_trabalhador);

    do {
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while ( opcao < 0 || opcao > 4);
    
    do {
    printf("| Digite o novo valor: ");
    scanf("%f", &valor);
    } while (valor < 0 || valor > 100);
    
    switch (opcao){
        case 1:
            taxa->geral_empregadora = valor;
            break;
        case 2:
            taxa->geral_trabalhador = valor;
            break;
        case 3:
            taxa->admin_empregadora = valor;
            break;
        case 4:
            taxa->admin_trabalhador = valor;
            break;
        case 0:
            break;
    }
        
}

//MOTRAR TODAS AS TAXAS
void mostrarTaxas(Taxas *taxa){
    printf( FORMATO_MOSTRAR_CRITERIOS, taxa->geral_empregadora, taxa->geral_trabalhador, taxa->admin_empregadora, taxa->admin_trabalhador);
}

//ALTERAR CRITERIO
void alterarCriterioIRS(ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado){
    
    int tabela, vencimento, num_filhos, i;
    float valor;
    
    do {
    printf(FORMATO_MENU_ALTERAR_IRS);
    scanf("%d", &tabela);
    } while ( tabela < 0 || tabela > 3);
    
    if (tabela == 1){
        printf("\n| ALTERAÇÃO DE CRITERIO NA TABELA DE DOIS TITULARES\n");
    } else if (tabela == 2){
        printf("\n| ALTERAÇÃO DE CRITERIO NA TABELA DE UNICO TITULAR\n");
    } else {
        printf("\n| ALTERAÇÃO DE CRITERIO NA TABELA NÃO CASADO\n");
    }
    
    do {
        printf("| Insira o vencimento (linha): ");
        scanf("%d", &vencimento);
    } while (verificarVencimento(tabela, vencimento, dois_titulares, unico_titular, nao_casado) != 1);
        
    do{
        printf("| Insira o numero de filhos (coluna): ");
        scanf("%d", &num_filhos);
    } while (num_filhos < 0);
    
    do {
        printf("| Insira o novo valor: ");
        scanf("%f", &valor);
    } while (valor < 0 || valor > 100);
    
    switch(tabela){
        case 1:
            for (i=0 ; i<dois_titulares->contador; i++){
                if (vencimento ==  dois_titulares->Dois_titulares_array[i].vencimento){
                    switch ( num_filhos ){
                        case 0:
                            dois_titulares->Dois_titulares_array[i].filho_zero = valor;
                            break;
                        case 1:
                            dois_titulares->Dois_titulares_array[i].filho_um = valor;
                            break;
                        case 2:
                            dois_titulares->Dois_titulares_array[i].filho_dois = valor;
                            break;
                        case 3:
                            dois_titulares->Dois_titulares_array[i].filho_tres = valor;
                            break;
                        case 4:
                            dois_titulares->Dois_titulares_array[i].filho_quatro = valor;
                            break;
                        default:
                            dois_titulares->Dois_titulares_array[i].filho_cinco = valor;
                            break;
                    }
                    break;
                }
            }
            puts(SUCESSO_IRS);
            break;
        case 2:
            for (i=0 ; i<unico_titular->contador; i++){
                if (vencimento ==  unico_titular->Unico_titular_array[i].vencimento){
                    switch ( num_filhos ){
                        case 0:
                            unico_titular->Unico_titular_array[i].filho_zero = valor;
                            break;
                        case 1:
                            unico_titular->Unico_titular_array[i].filho_um = valor;
                            break;
                        case 2:
                            unico_titular->Unico_titular_array[i].filho_dois = valor;
                            break;
                        case 3:
                            unico_titular->Unico_titular_array[i].filho_tres = valor;
                            break;
                        case 4:
                            unico_titular->Unico_titular_array[i].filho_quatro = valor;
                            break;
                        default:
                            unico_titular->Unico_titular_array[i].filho_cinco = valor;
                            break;
                    }
                    break;
                }
            }
            puts(SUCESSO_IRS);
            break;
        case 3:
            for (i=0 ; i<nao_casado->contador; i++){
                if (vencimento ==  nao_casado->Nao_casado_array[i].vencimento){
                    switch ( num_filhos ){
                        case 0:
                            nao_casado->Nao_casado_array[i].filho_zero = valor;
                            break;
                        case 1:
                            nao_casado->Nao_casado_array[i].filho_um = valor;
                            break;
                        case 2:
                            nao_casado->Nao_casado_array[i].filho_dois = valor;
                            break;
                        case 3:
                            nao_casado->Nao_casado_array[i].filho_tres = valor;
                            break;
                        case 4:
                            nao_casado->Nao_casado_array[i].filho_quatro = valor;
                            break;
                        default:
                            nao_casado->Nao_casado_array[i].filho_cinco = valor;
                            break;
                    }
                    break;
                }
            }
            puts(SUCESSO_IRS);
            break;
        case 0:
            break;
    }
}

//VERIFICAR VENCIMENTO
int verificarVencimento(int tabela, int vencimento, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado){
    int i;
    switch (tabela){
        case 1:
            for (i=0 ; i<dois_titulares->contador; i++){
                if (vencimento ==  dois_titulares->Dois_titulares_array[i].vencimento){
                    return (1);
                } 
            }
            puts(VENCIMENTO_ERRO);
            break;
        case 2:
            for (i=0 ; i<unico_titular->contador; i++){
                if (vencimento ==  unico_titular->Unico_titular_array[i].vencimento){
                    return (1);
                }
            }
            puts(VENCIMENTO_ERRO);
            break;
        case 3:
            for (i=0 ; i<nao_casado->contador; i++){
                if (vencimento ==  nao_casado->Nao_casado_array[i].vencimento){
                    return (1);
                } 
            }
            puts(VENCIMENTO_ERRO);
            break;
    }
}

//MOTRAR TODAS AS TABELAS IRS
void mostratTabelas(ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres){
    int tabela;
    
    do {
    printf("| 1) Tabela dois titulares \n");
    printf("| 2) Tabela unico titular \n");
    printf("| 3) Tabela nao casado \n");
    printf("| 0) sair \n");
    printf("| Digite a tabela que quer ver: ");
    scanf("%d", &tabela);
    } while ( tabela < 0 || tabela > 3);
    
    switch (tabela){
        case 1:
            logs("MOSTRAR TABELA DOIS TITULARES");
            puts("\n| TABELA DOIS TITULARES");
            for (int i=0; i < (array_um->contador)-2; i++){
                printf(FORMATO_MOSTRAR_TABELAS, array_um->Dois_titulares_array[i].vencimento, 
                        array_um->Dois_titulares_array[i].filho_zero,
                        array_um->Dois_titulares_array[i].filho_um,
                        array_um->Dois_titulares_array[i].filho_dois,
                        array_um->Dois_titulares_array[i].filho_tres,
                        array_um->Dois_titulares_array[i].filho_quatro,
                        array_um->Dois_titulares_array[i].filho_cinco);
            }
            break;
        case 2:
            logs("MOSTRAR TABELA UNICO TITULAR");
            puts("\n| TABELA UNICO TITULAR");     
            for (int i=0; i < (array_dois->contador)-2; i++){
                printf(FORMATO_MOSTRAR_TABELAS, array_dois->Unico_titular_array[i].vencimento, 
                        array_dois->Unico_titular_array[i].filho_zero,
                        array_dois->Unico_titular_array[i].filho_um,
                        array_dois->Unico_titular_array[i].filho_dois,
                        array_dois->Unico_titular_array[i].filho_tres,
                        array_dois->Unico_titular_array[i].filho_quatro,
                        array_dois->Unico_titular_array[i].filho_cinco);
            }
            break;
        case 3:
            logs("MOSTRAR TABELA NAO CASADO");
            puts("\n| TABELA NAO CASADO"); 
            for (int i=0; i < (array_tres->contador)-2; i++){
                printf(FORMATO_MOSTRAR_TABELAS, array_tres->Nao_casado_array[i].vencimento, 
                        array_tres->Nao_casado_array[i].filho_zero,
                        array_tres->Nao_casado_array[i].filho_um,
                        array_tres->Nao_casado_array[i].filho_dois,
                        array_tres->Nao_casado_array[i].filho_tres,
                        array_tres->Nao_casado_array[i].filho_quatro,
                        array_tres->Nao_casado_array[i].filho_cinco);
            }
            break;
    }
}

//FAZER LOGS
void logs(char *mensagem) {

    FILE *ficheiro_logs = fopen(FILENAME_LOG, "a");
    if (ficheiro_logs == NULL) {
        exit(EXIT_FAILURE);
    }

    fprintf(ficheiro_logs, FORMATO_LOGS, defineData(3), defineData(2), defineData(1), defineData(4), defineData(5), defineData(6), mensagem);

    fclose(ficheiro_logs);
}
