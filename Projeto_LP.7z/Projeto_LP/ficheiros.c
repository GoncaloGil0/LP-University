#include <stdio.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "ficheiros.h"
#include "menus.h"

//IMPORTAR USERS DOCUMENTO DO SISTEMA
int importar_users_sys(Empresa *arrayRH) {
    int n=0;
    FILE *ficheiro_users = fopen(FILENAME_USERS, "rb");
    if (ficheiro_users == NULL) {     
        return (0);
    } 

    while (fread(&arrayRH->funcionarios_array[arrayRH->contador], sizeof(Funcionario), 1, ficheiro_users)) {
        //aqui dentro é onde vou criar a formula de adicionar espaço ao array
        //cada vez que ele ler uma linha e adicionar no array essa linha, acrescenta um espaço ao array
        arrayRH->contador++;
        n++;
    }
    
    fclose(ficheiro_users);
    return (n);
}

//IMPORTAR SALARIOS DOCUMENTO DO SISTEMA
int importar_salarios_sys(Lista_calc *conta) {
    int n;
    FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS, "rb");
    if (ficheiro_salarios == NULL) {
        return (0);
    } 
    
    while(fread(&conta->calculo_array[conta->contador], sizeof (Conta), 1, ficheiro_salarios)){
        conta->contador++;
        n++;
        //aqui dentro é onde vou criar a formula de adicionar espaço ao array
        //cada vez que ele ler uma linha e adicionar no array essa linha, acrescenta um espaço ao array
    }
        
    fclose(ficheiro_salarios);
    return (n);
}

//IMPORTAR USERS DOCUMENTO DO UTILIZADOR
void importar_users_doc(Empresa *arrayRH){
    int n=0;
    char buffer[250], resposta;
    
    FILE *ficheiro_users = fopen(FILENAME_USERS_DOC, "r");
    if (ficheiro_users == NULL) {     
        puts(ERRO_FILE);
    }

    do {    
        fgets(buffer, sizeof(buffer), ficheiro_users);
     
        sscanf(buffer, FORMATO_USERS, &arrayRH->funcionarios_array[arrayRH->contador].codigo, 
                arrayRH->funcionarios_array[arrayRH->contador].nome, 
                &arrayRH->funcionarios_array[arrayRH->contador].numero_tlm, 
                &arrayRH->funcionarios_array[arrayRH->contador].est_civil,
                &arrayRH->funcionarios_array[arrayRH->contador].titulares,
                &arrayRH->funcionarios_array[arrayRH->contador].numero_filhos,
                &arrayRH->funcionarios_array[arrayRH->contador].cargo, 
                &arrayRH->funcionarios_array[arrayRH->contador].valor_hora,
                &arrayRH->funcionarios_array[arrayRH->contador].valor_sub_ali, 
                &arrayRH->funcionarios_array[arrayRH->contador].nascimento.dia,
                &arrayRH->funcionarios_array[arrayRH->contador].nascimento.mes, 
                &arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano,
                &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.dia, 
                &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.mes,
                &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano, 
                &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.dia,
                &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.mes, 
                &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.ano,
                &arrayRH->funcionarios_array[arrayRH->contador].ativo);
        
        arrayRH->contador++;
        n++;            
    } while(!feof(ficheiro_users));
    
    fclose(ficheiro_users);
    
    printf("|\n| Foram adicionados %d funcionarios \n", n);
    
    do {
    printf(PERGUNTA_INFO_GUARDADA);
    scanf(" %c", &resposta );
    } while ( resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');
    
    if (resposta == 'S' || resposta == 's') {
        
        for (int i=0; i<n ; i++){
            printf( FORMATO_MOSTRAR_USERS, arrayRH->funcionarios_array[(arrayRH->contador-n)+i].codigo, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].nome, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].numero_tlm, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].est_civil, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].titulares,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].numero_filhos,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].cargo, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].valor_hora,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].valor_sub_ali, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].nascimento.dia,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].nascimento.mes, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].nascimento.ano,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].entrada_emp.dia, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].entrada_emp.mes,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].entrada_emp.ano, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].saida_emp.dia,
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].saida_emp.mes, 
                    arrayRH->funcionarios_array[(arrayRH->contador-n)+i].saida_emp.ano);
        }
    }
}

//IMPORTAR SALARIOS DOCUMENTO DO UTILIZADOR
void importar_salarios_doc(Lista_calc *conta){
    
    // da exit sem ler POR CORRIGIR
    int n=0;
    printf("2");

    char buffer[250], resposta;
    
    FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS_DOC, "r");
    if (ficheiro_salarios == NULL) {     
        puts(ERRO_FILE);
    }
    
    do {
        fgets(buffer, sizeof(buffer), ficheiro_salarios);
        
        sscanf(buffer, FORMATO_SALARIOS, &conta->calculo_array[conta->contador].codigo, 
                &conta->calculo_array[conta->contador].ano,
                &conta->calculo_array[conta->contador].mes, 
                &conta->calculo_array[conta->contador].dias_compl,
                &conta->calculo_array[conta->contador].dias_meios, 
                &conta->calculo_array[conta->contador].dias_fds,
                &conta->calculo_array[conta->contador].dias_faltas);
   
        (conta->contador)++;
        n++;     
    } while(!feof(ficheiro_salarios));
    
    fclose(ficheiro_salarios);
    
    printf("|\n| Foram adicionados %d salarios \n", n);
    
    do {
    printf(PERGUNTA_INFO_GUARDADA);
    scanf(" %c", &resposta );
    } while ( resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');
    
    if (resposta == 'S' || resposta == 's') {
        
        for (int i=0; i<n ; i++){
        printf(FORMATO_MOSTRAR_SALARIOS, conta->calculo_array[i].codigo, 
                conta->calculo_array[i].ano,
                conta->calculo_array[i].mes, 
                conta->calculo_array[i].dias_compl,
                conta->calculo_array[i].dias_meios,
                conta->calculo_array[i].dias_fds,
                conta->calculo_array[i].dias_faltas);
        }
    }
}

//IMPORTAR TABELA DE IRS DOIS TITULARES
void importarTabela_um(Lista_um *array_um){
    
    FILE *ficheiro_dois_titulares = fopen(FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES, "rb");
    if (ficheiro_dois_titulares == NULL) {     
        puts(ERRO_FILE);
    } 

    while (fread(&array_um->Dois_titulares_array[array_um->contador], sizeof(Dois_titulares), 1, ficheiro_dois_titulares)) {
        //aqui dentro é onde vou criar a formula de adicionar espaço ao array
        //cada vez que ele ler uma linha e adicionar no array essa linha, acrescenta um espaço ao array
        array_um->contador++;
    }
    
    fclose(ficheiro_dois_titulares);
    puts("Importada");
    

/*
    for (int i=0; i < (array_um->contador)-1; i++){
        printf("%d %f %f %f %f %f %f \n", array_um->Dois_titulares_array[i].vencimento, 
                array_um->Dois_titulares_array[i].filho_zero,
                array_um->Dois_titulares_array[i].filho_um,
                array_um->Dois_titulares_array[i].filho_dois,
                array_um->Dois_titulares_array[i].filho_tres,
                array_um->Dois_titulares_array[i].filho_quatro,
                array_um->Dois_titulares_array[i].filho_cinco);
    }
*/
  
}

//IMPORTAR TABELA DE IRS UM TITULAR
void importarTabela_dois(Lista_dois *array_dois){
    
    FILE *ficheiro_unico_titular = fopen(FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR, "rb");
    if (ficheiro_unico_titular == NULL) {     
        puts(ERRO_FILE);
    } 

    
    while (fread(&array_dois->Unico_titular_array[array_dois->contador], sizeof(Unico_titular), 1, ficheiro_unico_titular)) {
        //aqui dentro é onde vou criar a formula de adicionar espaço ao array
        //cada vez que ele ler uma linha e adicionar no array essa linha, acrescenta um espaço ao array
        array_dois->contador++;
    }
    
    fclose(ficheiro_unico_titular);
    puts("Importada");

/*
    for (int i=0; i < (array_dois->contador)-1; i++){
        printf("%d %f %f %f %f %f %f \n", array_dois->Unico_titular_array[i].vencimento, 
                array_dois->Unico_titular_array[i].filho_zero,
                array_dois->Unico_titular_array[i].filho_um,
                array_dois->Unico_titular_array[i].filho_dois,
                array_dois->Unico_titular_array[i].filho_tres,
                array_dois->Unico_titular_array[i].filho_quatro,
                array_dois->Unico_titular_array[i].filho_cinco);
    }
*/

}

//IMPORTAR TABELA DE IRS NAO CASADO
void importarTabela_tres(Lista_tres *array_tres){
    
        FILE *ficheiro_nao_casado = fopen(FILENAME_DEPENDENTE_NAO_CASADO, "rb");
    if (ficheiro_nao_casado == NULL) {     
        puts(ERRO_FILE);
    } 

    
    while (fread(&array_tres->Nao_casado_array[array_tres->contador], sizeof(Nao_casado), 1, ficheiro_nao_casado)) {
        //aqui dentro é onde vou criar a formula de adicionar espaço ao array
        //cada vez que ele ler uma linha e adicionar no array essa linha, acrescenta um espaço ao array
        array_tres->contador++;
    }
    
    fclose(ficheiro_nao_casado);
    puts("Importada");
    

/*
    for (int i=0; i < (array_tres->contador)-1; i++){
        printf("%d %f %f %f %f %f %f \n", array_tres->Nao_casado_array[i].vencimento, 
                array_tres->Nao_casado_array[i].filho_zero,
                array_tres->Nao_casado_array[i].filho_um,
                array_tres->Nao_casado_array[i].filho_dois,
                array_tres->Nao_casado_array[i].filho_tres,
                array_tres->Nao_casado_array[i].filho_quatro,
                array_tres->Nao_casado_array[i].filho_cinco);
    }
*/

}

//GUARDAR TODOS OS DADOS EM MEMORIA
void guardar( Empresa *funcionarios, Lista_calc *conta, Lista_um *lista_um, Lista_dois *lista_dois, Lista_tres *lista_tres){

    //GUARDAR TODOS OS USERS
    FILE *ficheiro_users = fopen(FILENAME_USERS, "wb");
    if (ficheiro_users == NULL) {     
        puts(ERRO_FILE);
    } 
    
    for (int i = 0; i < funcionarios->contador; i++){
        fwrite(&funcionarios->funcionarios_array[i], sizeof (Funcionario), 1, ficheiro_users);
    }
        
    fclose(ficheiro_users);    
    printf("| Funcionarios: Guardado");
        
    //GUARDAR TODOS OS DADOS PARA O CALC DO SALARIO
    FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS, "wb");
    if (ficheiro_salarios == NULL) {     
        puts(ERRO_FILE);
    } 
    
    for (int i = 0; i < conta->contador; i++){
        fwrite(&conta->calculo_array[i], sizeof (Conta), 1, ficheiro_salarios);
    }
        
    fclose(ficheiro_salarios);
    printf("| Salarios: Guardado");
    
    //GUARDAR TABELA DE DOIS TITULARES
    FILE *ficheiro_dois_titulares = fopen(FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES, "wb");
    if (ficheiro_dois_titulares == NULL) {     
        puts(ERRO_FILE);
    } 
    
    for (int i = 0; i < lista_um->contador; i++){
        fwrite(&lista_um->Dois_titulares_array[i], sizeof (Dois_titulares), 1, ficheiro_dois_titulares);
    }
    
    fclose(ficheiro_dois_titulares);
    printf("| Tabela 1: Guardado");
    
    //GUARDAR TABELA DE UNICO TITULAR
    FILE *ficheiro_um_titular = fopen(FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR, "wb");
    if (ficheiro_um_titular == NULL) {     
        puts(ERRO_FILE);
    } 
    
    for (int x = 0; x < lista_dois->contador; x++){
        fwrite(&lista_dois->Unico_titular_array[x], sizeof (Unico_titular), 1, ficheiro_um_titular);
    }

    fclose(ficheiro_um_titular);
    printf("| Tabela 2: Guardado");

    //GUARDAR TABELA DE NAO CASADO
    FILE *ficheiro_nao_casado = fopen(FILENAME_DEPENDENTE_NAO_CASADO, "wb");
    if (ficheiro_nao_casado == NULL) {     
        puts(ERRO_FILE);
    } 
    
    for (int y = 0; y < lista_tres->contador; y++){
        fwrite(&lista_tres->Nao_casado_array[y], sizeof (Nao_casado), 1, ficheiro_nao_casado);
    }

    fclose(ficheiro_nao_casado);
    printf("| Tabela 3: Guardado");

}

//FAZER LOGS
void logs(char *mensagem) {

    FILE *ficheiro_logs = fopen(FILENAME_LOG, "a");
    if (ficheiro_logs == NULL) {
        exit(EXIT_FAILURE);
    }

    fprintf(ficheiro_logs, FORMATO_LOGS , defineData(3), defineData(2), defineData(1), defineData(4), defineData(5), defineData(6), mensagem);

    fclose(ficheiro_logs);
}
