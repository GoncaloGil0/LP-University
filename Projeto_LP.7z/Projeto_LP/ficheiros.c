#include <stdio.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "ficheiros.h"
#include "processar_info.h"
#include "menus.h"

//IMPORTAR USERS DOCUMENTO DO SISTEMA
int importar_users_sys(Empresa *arrayRH) {
    int n=0;
    
    Funcionario *temp;
    FILE *ficheiro_users;
    
    ficheiro_users = fopen(FILENAME_USERS, "rb");
    if (ficheiro_users == NULL) {
        return (0);
    } else {
        while (fread(&arrayRH->funcionarios_array[arrayRH->contador], sizeof (Funcionario), 1, ficheiro_users)) {
            arrayRH->contador++;
            n++;
            temp = (Funcionario*) realloc(arrayRH->funcionarios_array, arrayRH->contador * sizeof (Funcionario) + sizeof (Funcionario));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            arrayRH->funcionarios_array = temp;
            temp = NULL;
            free(temp);
        }
    }

    fclose(ficheiro_users);
    return (n);
}

//IMPORTAR SALARIOS PROCESSADOS DOCUMENTO DO SISTEMA
int importar_salarios_proc_sys(Lista_salarios *salarios){
    int n = 0;
    Calculo *temp;
    FILE *ficheiro_salarios_proc;
    
    ficheiro_salarios_proc = fopen(FILENAME_SALARIOS_PROCESSADOS, "rb");
    if (ficheiro_salarios_proc == NULL) {
        return (0);
    } else {
        while (fread(&salarios->calculo_array[salarios->contador], sizeof (Calculo), 1, ficheiro_salarios_proc)) {
            salarios->contador++;
            n++;
            temp = (Calculo*) realloc(salarios->calculo_array, salarios->contador * sizeof (Calculo) + sizeof (Calculo));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            salarios->calculo_array = temp;
            temp = NULL;
            free(temp);
        }
    }

    fclose(ficheiro_salarios_proc);
    return (n);
}

//IMPORTAR SALARIOS DOCUMENTO DO SISTEMA
int importar_salarios_sys(Lista_calc *conta) {
    int n;
    
    Conta *temp;
    FILE *ficheiro_salarios;
    
    ficheiro_salarios = fopen(FILENAME_SALARIOS, "rb");
    if (ficheiro_salarios == NULL) {
        return (0);
    } else {
        while (fread(&conta->calculo_array[conta->contador], sizeof (Conta), 1, ficheiro_salarios)) {
            conta->contador++;
            n++;
            temp = (Conta*) realloc(conta->calculo_array, conta->contador * sizeof (Conta) + sizeof (Conta));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            conta->calculo_array = temp;
            temp = NULL;
            free(temp);
        }
    }
    fclose(ficheiro_salarios);
    return (n);
}

//IMPORTAR USERS DOCUMENTO DO UTILIZADOR
void importar_users_doc(Empresa *arrayRH) {
    int n = 0;
    char buffer[250], resposta;
    
    Funcionario *temp;
    FILE *ficheiro_users;
    
    ficheiro_users = fopen(FILENAME_USERS_DOC, "r");
    if (ficheiro_users == NULL) {
        puts(ERRO_FILE);
    } else {
        while (fgets(buffer, sizeof (buffer), ficheiro_users)) {
            sscanf(buffer, FORMATO_USERS, &arrayRH->funcionarios_array[arrayRH->contador].codigo,
                    arrayRH->funcionarios_array[arrayRH->contador].nome,
                    &arrayRH->funcionarios_array[arrayRH->contador].numero_tlm,
                    &arrayRH->funcionarios_array[arrayRH->contador].est_civil,
                    &arrayRH->funcionarios_array[arrayRH->contador].titulares,
                    &arrayRH->funcionarios_array[arrayRH->contador].numero_filhos,
                    &arrayRH->funcionarios_array[arrayRH->contador].cargo,
                    &arrayRH->funcionarios_array[arrayRH->contador].valor_hora,
                    &arrayRH->funcionarios_array[arrayRH->contador].valor_sub_ali,
                    &arrayRH->funcionarios_array[arrayRH->contador].nascimento.dia,
                    &arrayRH->funcionarios_array[arrayRH->contador].nascimento.mes,
                    &arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano,
                    &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.dia,
                    &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.mes,
                    &arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano,
                    &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.dia,
                    &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.mes,
                    &arrayRH->funcionarios_array[arrayRH->contador].saida_emp.ano,
                    &arrayRH->funcionarios_array[arrayRH->contador].ativo);    
            
            arrayRH->contador++;
            n++;
            temp = (Funcionario*) realloc(arrayRH->funcionarios_array, arrayRH->contador * sizeof (Funcionario) + sizeof (Funcionario));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            arrayRH->funcionarios_array = temp;
            temp = NULL;
            free(temp);
        }
        fclose(ficheiro_users);

        printf("|\n| Foram adicionados %d funcionarios \n", n);
                
        do {
            printf(PERGUNTA_INFO_GUARDADA);
            scanf(" %c", &resposta);
        } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');

        if (resposta == 'S' || resposta == 's') {

            for (int i = 0; i < n; i++) {
                printf(FORMATO_MOSTRAR_USERS, arrayRH->funcionarios_array[(arrayRH->contador - n) + i].codigo,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nome,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].numero_tlm,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].est_civil,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].titulares,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].numero_filhos,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].cargo,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].valor_hora,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].valor_sub_ali,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nascimento.dia,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nascimento.mes,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].nascimento.ano,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].entrada_emp.dia,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].entrada_emp.mes,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].entrada_emp.ano,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].saida_emp.dia,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].saida_emp.mes,
                        arrayRH->funcionarios_array[(arrayRH->contador - n) + i].saida_emp.ano);
            }
        }
    }
}

//IMPORTAR SALARIOS DOCUMENTO DO UTILIZADOR
void importar_salarios_doc(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios) {
    int n = 0, opcao, porAdd = 0, atencao = 0;
    char buffer[250], resposta;
    
    Conta *temp;
    FILE *ficheiro_salarios;
    
    ficheiro_salarios = fopen(FILENAME_SALARIOS_DOC, "r");
    if (ficheiro_salarios == NULL) {
        puts(ERRO_FILE);
    } else {
        while (fgets(buffer, sizeof (buffer), ficheiro_salarios)) {
            sscanf(buffer, FORMATO_SALARIOS, &conta->calculo_array[conta->contador].codigo,
                    &conta->calculo_array[conta->contador].ano,
                    &conta->calculo_array[conta->contador].mes,
                    &conta->calculo_array[conta->contador].dias_compl,
                    &conta->calculo_array[conta->contador].dias_meios,
                    &conta->calculo_array[conta->contador].dias_fds,
                    &conta->calculo_array[conta->contador].dias_faltas);            
            if (procurarFuncionario(arrayRH, conta->calculo_array[conta->contador].codigo) == -1 ){
                porAdd++;
            }     
            if (verificacaoDiasDoc(conta->calculo_array[conta->contador].dias_compl, conta->calculo_array[conta->contador].dias_meios, conta->calculo_array[conta->contador].dias_fds, conta->calculo_array[conta->contador].dias_faltas, conta->calculo_array[conta->contador].mes, conta->calculo_array[conta->contador].ano) == 1){
                conta->calculo_array[conta->contador].estado = -1;
                atencao++;
            } else {
                conta->calculo_array[conta->contador].estado = 0;
            }            
            (conta->contador)++;
            n++;
            temp = (Conta*) realloc(conta->calculo_array, conta->contador * sizeof (Conta) + sizeof (Conta));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            conta->calculo_array = temp;
            temp = NULL;
            free(temp);
        }
        fclose(ficheiro_salarios);
        
        if (atencao == 0 && n != 0){
            printf("|\n| Foram adicionados %d salarios \n", n);
        } else if (atencao != 0){
            printf("|\n| Foram adicionados %d salarios e desses, %d sao invalidos\n", n, atencao);
        } else {
            printf("|\n| Não foram adicionados salarios \n");
        }        
        if (porAdd != 0){
            if (porAdd == 1){
                printf("|\n| O codigo seguinte nao tem conta criada: \n");
            } else {
                printf("|\n| Os seguintes codigos nao têm conta criada: \n");
            }
            printf("| Codigo:");
            for (int x=0; x != n ;x++){
                if (procurarFuncionario(arrayRH, conta->calculo_array[(conta->contador - n)+x].codigo) == -1 ){
                    printf(" %d ", conta->calculo_array[(conta->contador - n)+x].codigo);
                }
            } 
        } 
        do {
            printf(PERGUNTA_INFO_GUARDADA);
            scanf(" %c", &resposta);
        } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');

        if (resposta == 'S' || resposta == 's') {
            printf("|\n| SALARIOS ADICIONADOS: \n");
            for (int i = 0; i < n; i++) {
                printf(FORMATO_MOSTRAR_SALARIOS, conta->calculo_array[(conta->contador - n)+i].codigo,
                        conta->calculo_array[(conta->contador - n)+i].ano,
                        conta->calculo_array[(conta->contador - n)+i].mes,
                        conta->calculo_array[(conta->contador - n)+i].dias_compl,
                        conta->calculo_array[(conta->contador - n)+i].dias_meios,
                        conta->calculo_array[(conta->contador - n)+i].dias_fds,
                        conta->calculo_array[(conta->contador - n)+i].dias_faltas,
                        procToString(conta->calculo_array[(conta->contador - n)+i].estado));
            }
        }
        do {
            printf("| Deseja fazer o processamento salarial [s/n]? ");
            scanf(" %c", &resposta);        
        }while (resposta != 's' && resposta != 'S' && resposta != 'N' && resposta != 'n');

        if (resposta == 'S' || resposta == 's'){
            calcular(salarios, arrayRH, conta, taxa, dois_titulares, unico_titular, nao_casado, n);
        }
    }
}

//IMPORTAR TABELA DE IRS DOIS TITULARES
void importarDoisTitulares(DoisTitulares *dois_titulares) {
    IRS *temp;
    FILE *ficheiro_dois_titulares;
    
    ficheiro_dois_titulares = fopen(FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES, "rb");
    if (ficheiro_dois_titulares == NULL) {
        puts(ERRO_FILE);
    } else {
        while (fread(&dois_titulares->Dois_titulares_array[dois_titulares->contador], sizeof (IRS), 1, ficheiro_dois_titulares)) {
            dois_titulares->contador++;
            temp = (IRS*) realloc(dois_titulares->Dois_titulares_array, dois_titulares->contador * sizeof (IRS) + sizeof (IRS));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            dois_titulares->Dois_titulares_array = temp;
            temp = NULL;
            free(temp);
        }
        puts("Importada");
    }
    fclose(ficheiro_dois_titulares);
}

//IMPORTAR TABELA DE IRS UM TITULAR
void importarUnicoTitular(UnicoTitular *unico_titular) {
    IRS *temp;
    FILE *ficheiro_unico_titular;
    
    ficheiro_unico_titular = fopen(FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR, "rb");
    if (ficheiro_unico_titular == NULL) {
        puts(ERRO_FILE);
    } else {
        while (fread(&unico_titular->Unico_titular_array[unico_titular->contador], sizeof (IRS), 1, ficheiro_unico_titular)) {
            unico_titular->contador++;
            temp = (IRS*) realloc(unico_titular->Unico_titular_array, unico_titular->contador * sizeof (IRS) + sizeof (IRS));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            unico_titular->Unico_titular_array = temp;
            temp = NULL;
            free(temp);
        }
        puts("Importada");
    }
    fclose(ficheiro_unico_titular);
}

//IMPORTAR TABELA DE IRS NAO CASADO
void importarNaoCasado(NaoCasado *nao_casado) {
    IRS *temp;
    FILE *ficheiro_nao_casado;
    
    ficheiro_nao_casado= fopen(FILENAME_DEPENDENTE_NAO_CASADO, "rb");
    if (ficheiro_nao_casado == NULL) {
        puts(ERRO_FILE);
    } else {
        while (fread(&nao_casado->Nao_casado_array[nao_casado->contador], sizeof (IRS), 1, ficheiro_nao_casado)) {
            nao_casado->contador++;
            temp = (IRS*) realloc(nao_casado->Nao_casado_array, nao_casado->contador * sizeof (IRS) + sizeof (IRS));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            nao_casado->Nao_casado_array = temp;
            temp = NULL;
            free(temp);
        }
        puts("Importada");
    }
    fclose(ficheiro_nao_casado);
}

//IMPORTAR TABELA SS
void importarTablelaSS(Taxas *taxa) {
    
    char buffer[256];
    FILE *ficheiro_SS;
    
    ficheiro_SS = fopen(FILENAME_SS, "r");
    if (ficheiro_SS == NULL) {
        puts(ERRO_FILE);
    } else {
        fgets(buffer, sizeof (buffer), ficheiro_SS);
        sscanf(buffer, FORMATO_SS, &taxa->geral_empregadora, &taxa->geral_trabalhador, &taxa->admin_empregadora, &taxa->admin_trabalhador);
        printf("Importada");
    }
    fclose(ficheiro_SS);
}

//GUARDAR TODOS OS DADOS EM MEMORIA
void guardar(Empresa *funcionarios, Lista_calc *conta, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Taxas *taxa, Lista_salarios *salarios) {

    FILE *ficheiro_SS, *ficheiro_calculo, *ficheiro_users, *ficheiro_salarios, *ficheiro_dois_titulares, *ficheiro_um_titular, *ficheiro_nao_casado;
    printf("+ GUARDAR INFORMAÇÃO + \n");

    //GUARDAR TODOS OS USERS
    ficheiro_users = fopen(FILENAME_USERS, "wb");
    if (ficheiro_users == NULL) {
        puts(ERRO_FILE);
    } else {
        for (int i = 0; i < funcionarios->contador; i++) {
            fwrite(&funcionarios->funcionarios_array[i], sizeof (Funcionario), 1, ficheiro_users);
        }
        printf("| Funcionarios: Guardado \n");
    }
    
    fclose(ficheiro_users);
    
    //GUARDAR TODOS OS DADOS PARA O CALC DO SALARIO
    ficheiro_salarios = fopen(FILENAME_SALARIOS, "wb");
    if (ficheiro_salarios == NULL) {
        puts(ERRO_FILE);
    } else {
        for (int i = 0; i < conta->contador; i++) {
            fwrite(&conta->calculo_array[i], sizeof (Conta), 1, ficheiro_salarios);
        }
        printf("| Salarios: Guardado \n");
    }
    fclose(ficheiro_salarios);
    
    //GUARDAR DADOS DO PROCESSAMENTO DE SALARIOS
    ficheiro_calculo = fopen(FILENAME_SALARIOS_PROCESSADOS, "w");
    if (ficheiro_calculo == NULL) {
        puts(ERRO_FILE);
    } else {
        for (int y = 0; y < salarios->contador; y++) {
            fwrite(&salarios->calculo_array[y], sizeof (Calculo), 1, ficheiro_calculo);
        }
        printf("| Salarios processados: Guardado \n");
    }
    fclose(ficheiro_calculo);

    //GUARDAR TABELA DE DOIS TITULARES
    ficheiro_dois_titulares = fopen(FILENAME_DEPENDENTE_CASADO_DOIS_TITULARES, "wb");
    if (ficheiro_dois_titulares == NULL) {
        puts(ERRO_FILE);
    } else {
        for (int i = 0; i < dois_titulares->contador; i++) {
            fwrite(&dois_titulares->Dois_titulares_array[i], sizeof (IRS), 1, ficheiro_dois_titulares);
        }
        printf("| Tabela IRS 1: Guardado \n");
    }
    fclose(ficheiro_dois_titulares);

    //GUARDAR TABELA DE UNICO TITULAR
    ficheiro_um_titular = fopen(FILENAME_DEPENDENTE_CASADO_UNICO_TITULAR, "wb");
    if (ficheiro_um_titular == NULL) {
        puts(ERRO_FILE);
    } else {
        for (int x = 0; x < unico_titular->contador; x++) {
            fwrite(&unico_titular->Unico_titular_array[x], sizeof (IRS), 1, ficheiro_um_titular);
        }
        printf("| Tabela IRS 2: Guardado \n");
    }
    fclose(ficheiro_um_titular);

    //GUARDAR TABELA DE NAO CASADO
    ficheiro_nao_casado = fopen(FILENAME_DEPENDENTE_NAO_CASADO, "wb");
    if (ficheiro_nao_casado == NULL) {
        puts(ERRO_FILE);
    } else {
        for (int y = 0; y < nao_casado->contador; y++) {
            fwrite(&nao_casado->Nao_casado_array[y], sizeof (IRS), 1, ficheiro_nao_casado);
        }
        printf("| Tabela IRS 3: Guardado \n");
    }
    fclose(ficheiro_nao_casado);

    //GUARDAR DADOS SEGURANCA SOCIAL
    ficheiro_SS = fopen(FILENAME_SS, "w");
    if (ficheiro_SS == NULL) {
        puts(ERRO_FILE);
    } else {
        fprintf(ficheiro_SS, FORMATO_SS, taxa->geral_empregadora, taxa->geral_trabalhador, taxa->admin_empregadora, taxa->admin_trabalhador);
        printf("| Tabela SS: Guardado \n");
    }
    fclose(ficheiro_SS);
    
}

//ALTERAR CRITERIO SS
void alterarCriterioSS(Taxas *taxa) {
    int opcao;
    float valor;

    printf(FORMATO_CRITERIOS, taxa->geral_empregadora, taxa->geral_trabalhador, taxa->admin_empregadora, taxa->admin_trabalhador);

    do {
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 4);

    if (opcao != 0) {
        do {
           printf("| Digite o novo valor: ");
           scanf("%f", &valor);
        } while (valor < 0 || valor > 100);   
        
        switch (opcao) {
            case 1:
                taxa->geral_empregadora = valor;
                break;
            case 2:
                taxa->geral_trabalhador = valor;
                break;
            case 3:
                taxa->admin_empregadora = valor;
                break;
            case 4:
                taxa->admin_trabalhador = valor;
                break;
            case 0:
                break;
        }
    }
}

//MOTRAR TODAS AS TAXAS
void mostrarTaxas(Taxas *taxa) {
    printf(FORMATO_MOSTRAR_CRITERIOS, taxa->geral_empregadora, taxa->geral_trabalhador, taxa->admin_empregadora, taxa->admin_trabalhador);
}

//ALTERAR CRITERIO
void alterarCriterioIRS(DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado) {

    int tabela, vencimento, num_filhos, i;
    float valor;

    do {
        printf(FORMATO_MENU_ALTERAR_IRS);
        scanf("%d", &tabela);
    } while (tabela < 0 || tabela > 3);

    if (tabela == 1) {
        printf("\n| ALTERAÇÃO DE CRITERIO NA TABELA DE DOIS TITULARES\n");
    } else if (tabela == 2) {
        printf("\n| ALTERAÇÃO DE CRITERIO NA TABELA DE UNICO TITULAR\n");
    } else {
        printf("\n| ALTERAÇÃO DE CRITERIO NA TABELA NÃO CASADO\n");
    }

    do {
        printf("| Insira o vencimento (linha): ");
        scanf("%d", &vencimento);
    } while (verificarVencimento(tabela, vencimento, dois_titulares, unico_titular, nao_casado) != 1);

    do {
        printf("| Insira o numero de filhos (coluna): ");
        scanf("%d", &num_filhos);
    } while (num_filhos < 0 || num_filhos > 5);

    do {
        printf("| Insira o novo valor: ");
        scanf("%f", &valor);
    } while (valor < 0 || valor > 100);

    switch (tabela) {
        case 1:
            for (i = 0; i < dois_titulares->contador; i++) {
                if (vencimento == dois_titulares->Dois_titulares_array[i].vencimento) {
                    switch (num_filhos) {
                        case 0:
                            dois_titulares->Dois_titulares_array[i].filho_zero = valor;
                            break;
                        case 1:
                            dois_titulares->Dois_titulares_array[i].filho_um = valor;
                            break;
                        case 2:
                            dois_titulares->Dois_titulares_array[i].filho_dois = valor;
                            break;
                        case 3:
                            dois_titulares->Dois_titulares_array[i].filho_tres = valor;
                            break;
                        case 4:
                            dois_titulares->Dois_titulares_array[i].filho_quatro = valor;
                            break;
                        default:
                            dois_titulares->Dois_titulares_array[i].filho_cinco = valor;
                            break;
                    }
                    break;
                }
            }
            puts(SUCESSO_IRS);
            break;
        case 2:
            for (i = 0; i < unico_titular->contador; i++) {
                if (vencimento == unico_titular->Unico_titular_array[i].vencimento) {
                    switch (num_filhos) {
                        case 0:
                            unico_titular->Unico_titular_array[i].filho_zero = valor;
                            break;
                        case 1:
                            unico_titular->Unico_titular_array[i].filho_um = valor;
                            break;
                        case 2:
                            unico_titular->Unico_titular_array[i].filho_dois = valor;
                            break;
                        case 3:
                            unico_titular->Unico_titular_array[i].filho_tres = valor;
                            break;
                        case 4:
                            unico_titular->Unico_titular_array[i].filho_quatro = valor;
                            break;
                        default:
                            unico_titular->Unico_titular_array[i].filho_cinco = valor;
                            break;
                    }
                    break;
                }
            }
            puts(SUCESSO_IRS);
            break;
        case 3:
            for (i = 0; i < nao_casado->contador; i++) {
                if (vencimento == nao_casado->Nao_casado_array[i].vencimento) {
                    switch (num_filhos) {
                        case 0:
                            nao_casado->Nao_casado_array[i].filho_zero = valor;
                            break;
                        case 1:
                            nao_casado->Nao_casado_array[i].filho_um = valor;
                            break;
                        case 2:
                            nao_casado->Nao_casado_array[i].filho_dois = valor;
                            break;
                        case 3:
                            nao_casado->Nao_casado_array[i].filho_tres = valor;
                            break;
                        case 4:
                            nao_casado->Nao_casado_array[i].filho_quatro = valor;
                            break;
                        default:
                            nao_casado->Nao_casado_array[i].filho_cinco = valor;
                            break;
                    }
                    break;
                }
            }
            puts(SUCESSO_IRS);
            break;
        case 0:
            break;
    }
}

//VERIFICAR VENCIMENTO
int verificarVencimento(int tabela, int vencimento, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado) {
    int i;
    switch (tabela) {
        case 1:
            for (i = 0; i < dois_titulares->contador; i++) {
                if (vencimento == dois_titulares->Dois_titulares_array[i].vencimento) {
                    return (1);
                }
            }
            puts(VENCIMENTO_ERRO);
            break;
        case 2:
            for (i = 0; i < unico_titular->contador; i++) {
                if (vencimento == unico_titular->Unico_titular_array[i].vencimento) {
                    return (1);
                }
            }
            puts(VENCIMENTO_ERRO);
            break;
        case 3:
            for (i = 0; i < nao_casado->contador; i++) {
                if (vencimento == nao_casado->Nao_casado_array[i].vencimento) {
                    return (1);
                }
            }
            puts(VENCIMENTO_ERRO);
            break;
    }
}

//MOTRAR TODAS AS TABELAS IRS
void mostratTabelas(DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado) {
    int tabela;

    do {
        printf("| 1) Tabela dois titulares \n");
        printf("| 2) Tabela unico titular \n");
        printf("| 3) Tabela nao casado \n");
        printf("| 0) sair \n");
        printf("| Digite a tabela que quer ver: ");
        scanf("%d", &tabela);
    } while (tabela < 0 || tabela > 3);

    switch (tabela) {
        case 1:
            logs("MOSTRAR TABELA DOIS TITULARES");
            puts("\n| TABELA DOIS TITULARES");
            for (int i = 0; i < (dois_titulares->contador) - 2; i++) {
                printf(FORMATO_MOSTRAR_TABELAS, dois_titulares->Dois_titulares_array[i].vencimento,
                        dois_titulares->Dois_titulares_array[i].filho_zero,
                        dois_titulares->Dois_titulares_array[i].filho_um,
                        dois_titulares->Dois_titulares_array[i].filho_dois,
                        dois_titulares->Dois_titulares_array[i].filho_tres,
                        dois_titulares->Dois_titulares_array[i].filho_quatro,
                        dois_titulares->Dois_titulares_array[i].filho_cinco);
            }
            break;
        case 2:
            logs("MOSTRAR TABELA UNICO TITULAR");
            puts("\n| TABELA UNICO TITULAR");
            for (int i = 0; i < (unico_titular->contador) - 2; i++) {
                printf(FORMATO_MOSTRAR_TABELAS, unico_titular->Unico_titular_array[i].vencimento,
                        unico_titular->Unico_titular_array[i].filho_zero,
                        unico_titular->Unico_titular_array[i].filho_um,
                        unico_titular->Unico_titular_array[i].filho_dois,
                        unico_titular->Unico_titular_array[i].filho_tres,
                        unico_titular->Unico_titular_array[i].filho_quatro,
                        unico_titular->Unico_titular_array[i].filho_cinco);
            }
            break;
        case 3:
            logs("MOSTRAR TABELA NAO CASADO");
            puts("\n| TABELA NAO CASADO");
            for (int i = 0; i < (nao_casado->contador) - 2; i++) {
                printf(FORMATO_MOSTRAR_TABELAS, nao_casado->Nao_casado_array[i].vencimento,
                        nao_casado->Nao_casado_array[i].filho_zero,
                        nao_casado->Nao_casado_array[i].filho_um,
                        nao_casado->Nao_casado_array[i].filho_dois,
                        nao_casado->Nao_casado_array[i].filho_tres,
                        nao_casado->Nao_casado_array[i].filho_quatro,
                        nao_casado->Nao_casado_array[i].filho_cinco);
            }
            break;
    }
}

//FAZER LOGS
void logs(char *mensagem) {

    FILE *ficheiro_logs = fopen(FILENAME_LOG, "a");
    if (ficheiro_logs == NULL) {
        exit(EXIT_FAILURE);
    } else {
        fprintf(ficheiro_logs, FORMATO_LOGS, defineData(3), defineData(2), defineData(1), defineData(4), defineData(5), defineData(6), mensagem);
    }
    fclose(ficheiro_logs);
}

//LIMPAR MEMORIA
void limpar_memoria(){
    
    char resposta;
    
    printf("\n+ APAGAR TODA A INFORMAÇÃO + \n");
    
    do {
        printf("| Tem a certeza que quer apagar todos os dados dos ficheiros (users, salarios, salarios processados) [s/n]? ");
        scanf(" %c", &resposta);
    } while (resposta != 's' && resposta != 'S' && resposta != 'N' && resposta != 'n');

    if (resposta == 'S' || resposta == 's'){       
        logs("APAGAR INFORMAÇÃO");
        //APAGAR TODOS OS USERS
        FILE *ficheiro_users = fopen(FILENAME_USERS, "wb");
        if (ficheiro_users == NULL) {
            puts(ERRO_FILE);
        } else {
            printf("| Funcionarios: Apagado \n");
        }

        fclose(ficheiro_users);

        //APAGAR TODOS OS DADOS PARA O CALC DO SALARIO
        FILE *ficheiro_salarios = fopen(FILENAME_SALARIOS, "wb");
        if (ficheiro_salarios == NULL) {
            puts(ERRO_FILE);
        } else {
            printf("| Salarios: Apagado \n");
        }
        fclose(ficheiro_salarios);

        //APAGAR DADOS DO PROCESSAMENTO DE SALARIOS
        FILE *ficheiro_calculo = fopen(FILENAME_SALARIOS_PROCESSADOS, "w");
        if (ficheiro_calculo == NULL) {
            puts(ERRO_FILE);
        } else {
            printf("| Salarios processados: Apagado \n");
        }
        fclose(ficheiro_calculo);
    }
}

//CRIAR FICHEIROS PARA O USER
void criarFicheirosUser(Empresa *arrayRH, Lista_calc *conta, Lista_salarios *salarios){
    int escolha;
    FILE *ficheiro_users, *ficheiro_salarios, *ficheiro_conta;

    do {
        printf("\n+ FICHEIRO +\n");
        printf("| 1) Listagem de funcionarios\n");
        printf("| 2) Listagem de dados para cálculos\n");
        printf("| 3) Listagem de cálculos processados\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &escolha);
    } while (escolha < 0 || escolha > 3);
    
    switch (escolha) {
        case 1:
            ficheiro_users = fopen(FILENAME_USERS_TEXTO, "w");
            if (ficheiro_users == NULL) {
                puts(ERRO_FILE);
            } else if (arrayRH->contador == 0) {
                printf(NAO_EXISTEM, "UTILIZADORES");
            } else {
                
                for (int i = 0; i < arrayRH->contador; i++) {
                    fprintf(ficheiro_users, FORMATO_MOSTRAR_USERS,
                            arrayRH->funcionarios_array[i].codigo,
                            arrayRH->funcionarios_array[i].nome,
                            arrayRH->funcionarios_array[i].numero_tlm,
                            est_civilToString(arrayRH->funcionarios_array[i].est_civil),
                            arrayRH->funcionarios_array[i].titulares,
                            arrayRH->funcionarios_array[i].numero_filhos,
                            cargoToString(arrayRH->funcionarios_array[i].cargo),
                            arrayRH->funcionarios_array[i].valor_hora,
                            arrayRH->funcionarios_array[i].valor_sub_ali,
                            arrayRH->funcionarios_array[i].nascimento.dia,
                            arrayRH->funcionarios_array[i].nascimento.mes,
                            arrayRH->funcionarios_array[i].nascimento.ano,
                            arrayRH->funcionarios_array[i].entrada_emp.dia,
                            arrayRH->funcionarios_array[i].entrada_emp.mes,
                            arrayRH->funcionarios_array[i].entrada_emp.ano,
                            arrayRH->funcionarios_array[i].saida_emp.dia,
                            arrayRH->funcionarios_array[i].saida_emp.mes,
                            arrayRH->funcionarios_array[i].saida_emp.ano);
                     printf("Linha \n");
                }
                fclose(ficheiro_users);
                break;
            }
        case 2:
            ficheiro_conta = fopen(FILENAME_SALARIOS_TEXTO, "w");
            if (ficheiro_conta == NULL) {
                puts(ERRO_FILE);
            } else  if ( conta->contador == 0) {
                printf(NAO_EXISTEM, "SALARIOS POR PROCESSAR");
            } else {
                for (int i = 0; i < conta->contador; i++) {
                    fprintf(ficheiro_conta, FORMATO_MOSTRAR_SALARIOS,
                            conta->calculo_array[i].codigo,
                            conta->calculo_array[i].dias_compl,
                            conta->calculo_array[i].dias_meios,
                            conta->calculo_array[i].dias_fds,
                            conta->calculo_array[i].dias_faltas,
                            conta->calculo_array[i].ano,
                            conta->calculo_array[i].mes,
                            procToString(conta->calculo_array[i].estado));
                     printf("Linha \n");
                }
                fclose(ficheiro_conta);
                break;
            }
        case 3:
            ficheiro_salarios = fopen(FILENAME_CALCULOS_TEXTO, "w");
            if (ficheiro_salarios == NULL) {
                puts(ERRO_FILE);
            } else if ( salarios->contador == 0) {
                printf(NAO_EXISTEM, "SALARIOS PROCESSADOS");
            } else {
                for (int i = 0; i < salarios->contador; i++) {
                    fprintf(ficheiro_salarios, FORMATO_MOSTRAR_SALARIOS_TODOS,
                            salarios->calculo_array[i].codigo,
                            salarios->calculo_array[i].venc_iliquido,
                            salarios->calculo_array[i].bonus,
                            salarios->calculo_array[i].sub_ali,
                            salarios->calculo_array[i].ss_ent_patronal,
                            salarios->calculo_array[i].ss_ent_pessoal,
                            salarios->calculo_array[i].irs,
                            salarios->calculo_array[i].venc_liquido,
                            salarios->calculo_array[i].encargo_total_emp);
                }
                fclose(ficheiro_salarios);
                break;
            }
        case 0:
            break;
    }
}

//VALIDAÇÃO DO SOMATORIO DOS DIAS 
int verificacaoDiasDoc(int dias_compl, int dias_meios, int dias_fds, int dias_faltas, int mes, int ano) {

    if ((dias_compl + dias_meios + dias_fds + dias_faltas) > saberDiaMax(ano, mes)) {
        return 1;
    }
    if ((dias_compl + dias_meios + dias_fds + dias_faltas) < saberDiaMax(ano, mes)) {
        return 1;
    }
}