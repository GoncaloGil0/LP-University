#ifndef PEDIR_INFO_H
#define PEDIR_INFO_H


//CONSTANTES
#define MAX_CODIGO 9999
#define MIN_CODIGO 1
#define OBTER_CODIGO "| Código: "

#define MAX_NOME  10
#define OBTER_NOME "| Nome: "

#define MAX_NUM_TELE 969999999
#define MIN_NUM_TELE 910000000
#define OBTER_NUM_TELE "| Número de telemóvel: "

#define EST_CIVIL "| Estado civil: "
#define CARGO "| Cargo na empresa: "
#define OBTER_EST_CIVIL "| Estado civil [0-Casado 1-Solteiro 2-Divorciado 3-Viuvo]: "
#define OBTER_TITULARES "| Numero de titulares: "
#define OBTER_NUM_FILHOS "| Número de filhos: "
#define OBTER_CARGO "| Cargo na empresa [0-Empregado 1-Chefe 2-Administrador]: "
#define OBTER_SALARIO "| Salário por hora: "
#define OBTER_SUB_ALI "| Subsi­dio de alimentação: "

#define MIN_DIA 1
#define MAX_MES 12
#define MIN_MES 1
#define MIN_ANO 1950

#define OBTER_DATA_NASC "| Data de nascimento: "
#define OBTER_DATA_ENT "| Data de entrada na empresa: "
#define OBTER_DATA_SAIDA "| Data de saída da empresa: "

#define OBTER_DIA "| Dia: "
#define OBTER_MES "| Mes: "
#define OBTER_ANO "| Ano: "

#define TITLE_CALC "| Insira os dados para o calculo"
#define OBTER_NUM_ANO "| Ano: "
#define OBTER_NUM_MES "| Mes: "
#define OBTER_DIAS_COMPL "| Numero de dias completos trabalhados: "
#define OBTER_DIAS_MEIOS "| Numero de meios dias trabalhados: "
#define OBTER_DIAS_FDS "| Numero de dias trabalhados ao fim de semana: "
#define OBTER_DIAS_FALTAS "| Numero de dias de faltas: "
#define MIN_DIAS_TRABALHO 0

#define VALOR_INVALIDO "| !VALOR INVALIDO!"
#define NOME_INVALIDO "| !NOME INVALIDO!"
#define FUNC_EXISTENTE "| !FUNCIONARIO JÁ EXISTENTE!"
#define LISTA_CHEIA "| !LISTA CHEIA! "
#define DIAS_MAIOR_MES "| !DIAS ULTRAPASSAM OS DIAS DO MES!"
#define DIAS_FALTA_MES "| !NUMERO DE DIAS INCORRETO!"
#define FUNC_INEXISTENTE "| !FUNCIONARIO INEXISTÊNTE! "
#define DATA_IVALIDA_MENOR "| !DATA INVALIDA (MENOR DE IDADE)! "

#define SUCESSO "| Operação realizada com sucesso"
#define ERRO "| Algo deu errado"

//REGISTOS

//ESTADO CIVIL
typedef enum {
    CASADO, SOLTEIRO, DIVORCIADO, VIUVO
} Est_Civil;

//CARGO EMPRESA
typedef enum {
    EMPREGADO, CHEFE, ADMINISTRADOR
} Cargo;

//DATAS
typedef struct {
    int dia, mes, ano;
} Data;

//FUNCIONARIO INFO
typedef struct {
    long numero_tlm;
    int codigo, numero_filhos, titulares; // se titulares = 0 quer dizer que n se aplica
    char nome[MAX_NOME];
    Est_Civil est_civil;
    Cargo cargo;
    float valor_hora, valor_sub_ali;
    Data nascimento, entrada_emp, saida_emp;
    int ativo; // 1 = ativo e 0 = inativo
} Funcionario;

//ARRAY FUNCIONARIOS + CONTADOR
typedef struct {
    int contador;
    Funcionario *funcionarios_array;
} Empresa;

//CACLCULO SALARIAL
typedef struct {
    int codigo, dias_compl, dias_meios, dias_fds, dias_faltas, mes, ano, proc; //proc == 1 quer dizer que ja foi processado, proc ==0 nao foi 
} Conta;

//ARRAY CALCULOS + CONTADOR
typedef struct {
    int contador;
    Conta *calculo_array;
} Lista_calc;

//FUNÇOES
int defineData(int pedido);
void cleanInputBuffer();
int obterInt(int min, int max, char *texto);
void obterString(char *string, unsigned int tamanho, char *texto);
long obterNum(long min, long max, char *texto);
char *est_civilToString(Est_Civil tipo);
char *cargoToString(Cargo tipo);
void addFuncionario(Empresa *arrayRH, int codigo);
int procurarFuncionario(Empresa *arrayRH, int codigo);
void verificacaoAddFuncionarios(Empresa *arrayRH);
void editarFuncionario(Empresa *arrayRH, int posicao, int opcao);
int infoFuncionario(Empresa *arrayRH, int posicao);
void verificacaoEditarFuncionarios(Empresa *arrayRH);
void removerFuncionario(Empresa * arrayRH);
int obterNumDias(char *texto);
int verificacaoDias(int dias_compl, int dias_meios, int dias_fds, int dias_faltas, int mes, int ano);
void verificacaoFuncionariosCalculo(Lista_calc *conta, Empresa *arrayRH);
void calcSalarial(Lista_calc *conta, int codigo);
int saberDiaMax(int ano, int mes);
int saberDia(char *TEXTO, int ano, int mes);
int saberMes(char *TEXTO, int ano);
int saberAno(char *TEXTO);

#endif
