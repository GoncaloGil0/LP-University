#ifndef PEDIR_INFO_H
#define PEDIR_INFO_H

//CONSTANTES
#define MAX_CODIGO 9999
#define MIN_CODIGO 1
#define OBTER_CODIGO "| Código: "

#define MAX_NOME  10
#define OBTER_NOME "| Nome: "

#define MAX_NUM_TELE 969999999
#define MIN_NUM_TELE 910000000
#define OBTER_NUM_TELE "| Número de telemóvel: "

#define EST_CIVIL "| Estado civil: "
#define CARGO "| Cargo na empresa: "
#define OBTER_EST_CIVIL "| Estado civil [0-Casado 1-Solteiro 2-Divorciado 3-Viuvo]: "
#define OBTER_TITULARES "| Numero de titulares: "
#define OBTER_NUM_FILHOS "| Número de filhos: "
#define OBTER_CARGO "| Cargo na empresa [0-Empregado 1-Chefe 2-Administrador]: "
#define OBTER_SALARIO "| Salário por hora: "
#define OBTER_SUB_ALI "| Subsidio de alimentação: "

#define MIN_DIA 1
#define MAX_MES 12
#define MIN_MES 1
#define MIN_ANO 1950

#define OBTER_DATA_NASC "| Data de nascimento: "
#define OBTER_DATA_ENT "| Data de entrada na empresa: "
#define OBTER_DATA_SAIDA "| Data de saída da empresa: "

#define OBTER_DIA "| Dia: "
#define OBTER_MES "| Mes: "
#define OBTER_ANO "| Ano: "

#define TITLE_CALC "| Insira os dados para o calculo"
#define OBTER_NUM_ANO "| Ano: "
#define OBTER_NUM_MES "| Mes: "
#define OBTER_DIAS_COMPL "| Numero de dias completos trabalhados: "
#define OBTER_DIAS_MEIOS "| Numero de meios dias trabalhados: "
#define OBTER_DIAS_FDS "| Numero de dias trabalhados ao fim de semana: "
#define OBTER_DIAS_FALTAS "| Numero de dias de faltas: "
#define MIN_DIAS_TRABALHO 0

#define VALOR_INVALIDO "| !VALOR INVALIDO!"
#define NOME_INVALIDO "| !NOME INVALIDO!"
#define FUNC_EXISTENTE "| !FUNCIONARIO JÁ EXISTENTE!"
#define LISTA_CHEIA "| !LISTA CHEIA! "
#define DIAS_MAIOR_MES "| !DIAS ULTRAPASSAM OS DIAS DO MES!"
#define DIAS_FALTA_MES "| !NUMERO DE DIAS INCORRETO!"
#define FUNC_INEXISTENTE "| !FUNCIONARIO INEXISTÊNTE! "
#define DATA_IVALIDA_MENOR "| !DATA INVALIDA (MENOR DE IDADE)! "
#define DATA_INVALIDA_SALARIO "| !O FUNCIONARIO NAO SE ENCONTRA NA EMPRESA NESSE %s! \n"

#define SUCESSO "| Operação realizada com sucesso"
#define ERRO "| !Algo deu errado"

//REGISTOS

//ESTADO CIVIL
typedef enum {
    CASADO, SOLTEIRO, DIVORCIADO, VIUVO
} Est_Civil;

//CARGO EMPRESA
typedef enum {
    EMPREGADO, CHEFE, ADMINISTRADOR
} Cargo;

//DATAS
typedef struct {
    int dia, mes, ano;
} Data;

//FUNCIONARIO INFO
typedef struct {
    long numero_tlm;
    int codigo, numero_filhos, titulares;
    char nome[MAX_NOME];
    Est_Civil est_civil;
    Cargo cargo;
    float valor_hora, valor_sub_ali;
    Data nascimento, entrada_emp, saida_emp;
    int ativo; // 1 = ativo e 0 = inativo
} Funcionario;

//ARRAY FUNCIONARIOS
typedef struct {
    int contador;
    Funcionario *funcionarios_array;
} Empresa;

//CACLCULO SALARIAL
typedef struct {
    int codigo, dias_compl, dias_meios, dias_fds, dias_faltas, mes, ano, estado; //estado==1 ja foi processado, estado==0 nao foi ainda
} Conta;

//ARRAY CALCULOS
typedef struct {
    int contador;
    Conta *calculo_array;
} Lista_calc;

//TADELAS IRS
typedef struct {
    float filho_zero, filho_um, filho_dois, filho_tres, filho_quatro, filho_cinco;
    int vencimento;
} IRS;

//DEPENDENTE_CASADO_DOIS_TITULARES
typedef struct{
    int contador;
    IRS *Dois_titulares_array;
} DoisTitulares;

//DEPENDENTE_CASADO_UNICO_TITULARES
typedef struct{
    int contador;
    IRS *Unico_titular_array;
} UnicoTitular;

//DEPENDENTE_NAO_CASADO
typedef struct{
    int contador;
    IRS *Nao_casado_array;
} NaoCasado;

//TAXAS SS
typedef struct {
    float geral_empregadora, geral_trabalhador, admin_empregadora, admin_trabalhador;
} Taxas;

//CALCULO
typedef struct{ 
    int codigo;
    float venc_liquido, venc_iliquido, encargo_total_emp, irs, sub_ali, bonus, ss_ent_patronal, ss_ent_pessoal;
} Calculo;

typedef struct{ 
    int contador;
    Calculo *calculo_array;
} Lista_salarios;

//FUNÇOES
int defineData(int pedido);
void cleanInputBuffer();
int obterInt(int min, int max, char *texto);
void obterString(char *string, unsigned int tamanho, char *texto);
long obterNum(long min, long max, char *texto);
char *est_civilToString(Est_Civil tipo);
char *cargoToString(Cargo tipo);
char *procToString(int proc);
void addFuncionario(Empresa *arrayRH, int codigo);
int procurarFuncionario(Empresa *arrayRH, int codigo);
void verificacaoAddFuncionarios(Empresa *arrayRH);
void editarFuncionario(Empresa *arrayRH, int posicao, int opcao);
int infoFuncionario(Empresa *arrayRH, int posicao);
void verificacaoEditarFuncionarios(Empresa *arrayRH);
void removerFuncionario(Empresa * arrayRH);
int obterNumDias(char *texto);
int verificacaoDias(int dias_compl, int dias_meios, int dias_fds, int dias_faltas, int mes, int ano);
void verificacaoFuncionariosCalculo(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios);
void calcSalarial(Lista_calc *conta, int codigo, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios);
int saberDiaMax(int ano, int mes);
int saberDia(char *TEXTO, int ano, int mes);
int saberMes(char *TEXTO, int ano);
int saberAno(char *TEXTO);

#endif
