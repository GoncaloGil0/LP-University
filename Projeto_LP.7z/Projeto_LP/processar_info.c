//Bibliotecas
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//headers
#include "pedir_info.h"
#include "ficheiros.h"
#include "menus.h"
#include "processar_info.h"

//SABER TAXA DA SS
float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa){
    
    if (entidade == 1) { // trabalhador
        
        switch (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].cargo){
            case 0: //empregado 
                return (taxa->geral_trabalhador);
                break;
            case 1: //chefe
                return (taxa->admin_trabalhador);
                break;
            case 2: //administrador
                return (taxa->admin_trabalhador);
                break;
            default:
                puts("ERRO");
        }
    } else { //entidade empregadora
        
        switch (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].cargo){
            case 0: //empregado 
                return (taxa->geral_empregadora);
                break;
            case 1: //chefe
                return (taxa->admin_empregadora);
                break;
            case 2: //administrador
                return (taxa->admin_empregadora);
                break;
            default:
                puts("ERRO");
        }
    }
}

//SABER TAXA DO IRS
float saberIRS(int vencimento, int codigo, Empresa *arrayRH, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado){
    
    int posicao = procurarFuncionario(arrayRH, codigo);
    
    if ( arrayRH->funcionarios_array[posicao].titulares == 1 ){ //unico titular
        
        for (int i=0 ; i<unico_titular->contador; i++){
            
            if ((unico_titular->Unico_titular_array[i].vencimento < vencimento && vencimento < unico_titular->Unico_titular_array[i++].vencimento) || vencimento ==  unico_titular->Unico_titular_array[i].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (unico_titular->Unico_titular_array[i++].filho_zero);
                        break;
                    case 1:
                        return (unico_titular->Unico_titular_array[i++].filho_um);
                        break;
                    case 2:
                        return (unico_titular->Unico_titular_array[i++].filho_dois);
                        break;
                    case 3:
                        return (unico_titular->Unico_titular_array[i++].filho_tres);
                        break;
                    case 4:
                        return (unico_titular->Unico_titular_array[i++].filho_quatro);
                        break;
                    default:
                        return (unico_titular->Unico_titular_array[i++].filho_cinco);
                        break;
                }
                break;
            }
        }
    } else if (arrayRH->funcionarios_array[posicao].titulares == 2){ //dois titulares
        
        for (int i=0 ; i<dois_titulares->contador; i++){
            
            if ((dois_titulares->Dois_titulares_array[i].vencimento < vencimento && vencimento < dois_titulares->Dois_titulares_array[i++].vencimento) || vencimento ==  dois_titulares->Dois_titulares_array[i].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (dois_titulares->Dois_titulares_array[i++].filho_zero);
                        break;
                    case 1:
                        return (dois_titulares->Dois_titulares_array[i++].filho_um);
                        break;
                    case 2:
                        return (dois_titulares->Dois_titulares_array[i++].filho_dois);
                        break;
                    case 3:
                        return (dois_titulares->Dois_titulares_array[i++].filho_tres);
                        break;
                    case 4:
                        return (dois_titulares->Dois_titulares_array[i++].filho_quatro);
                        break;
                    default:
                        return (dois_titulares->Dois_titulares_array[i++].filho_cinco);
                        break;
                }
            }
        }
    } else { //nao casado
        for (int i=0 ; i<nao_casado->contador; i++){
            
            if ((nao_casado->Nao_casado_array[i].vencimento < vencimento && vencimento < nao_casado->Nao_casado_array[i++].vencimento) || vencimento ==  nao_casado->Nao_casado_array[i].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (nao_casado->Nao_casado_array[i++].filho_zero);
                        break;
                    case 1:
                        return (nao_casado->Nao_casado_array[i++].filho_um);
                        break;
                    case 2:
                        return (nao_casado->Nao_casado_array[i++].filho_dois);
                        break;
                    case 3:
                        return (nao_casado->Nao_casado_array[i++].filho_tres);
                        break;
                    case 4:
                        return (nao_casado->Nao_casado_array[i++].filho_quatro);
                        break;
                    default:
                        return (nao_casado->Nao_casado_array[i++].filho_cinco);
                        break;
                }
            }
        }
    }
}

//FAZER O CALCULO SALARIAL
void calcular(Lista_salarios *salarios, Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado, int num_salarios){
    
    Calculo *temp;
    
    int x, vencimento_iliquido, posicao_func, horasTrabalhadas;
    
    float diasCompletos, diasMeios, diasFds, diasCompletosAlm, diasMeiosAlm, diaFdsAlm, alimetacaoTotal;
    float IRS_func, IRS_emp, SS_func, SS_emp, bonus, vencimento_liquido;
    
    if (num_salarios == 0){ //para se ver todos os utilizadores num_salarios = 0
        num_salarios = conta->contador;
    }
        
    for(x=0; x <= num_salarios; x++){
                
        if (conta->calculo_array[(conta->contador - num_salarios) + x].proc == 0){ //verificar se o salario ja foi processado ou nao
            
            //SABER A POSIÇÃO DO FUNCIONARIO NA LISTA
            posicao_func = procurarFuncionario(arrayRH, conta->calculo_array[(conta->contador - num_salarios) + x].codigo);
            
            //CALCULO DO BONUS
            horasTrabalhadas = ((8*conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl)+(4*conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios)+(8*conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds));
            
            //CALCULAR SALARIO ILIQUIDO (COM O SUB DE ALIMENTAÇÃO E BONUS)
            diasCompletos = arrayRH->funcionarios_array[posicao_func].valor_hora * ( 8 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl);
            diasMeios = arrayRH->funcionarios_array[posicao_func].valor_hora * ( 4 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios);
            diasFds = (arrayRH->funcionarios_array[posicao_func].valor_hora * 1.5) * ( 8 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds); 

            diasCompletosAlm = arrayRH->funcionarios_array[posicao_func].valor_sub_ali * ( 8 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl);
            diasMeiosAlm = arrayRH->funcionarios_array[posicao_func].valor_sub_ali * ( 4 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios);
            diaFdsAlm = (arrayRH->funcionarios_array[posicao_func].valor_sub_ali * 1.5) * ( 8 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds);

            alimetacaoTotal = diasCompletosAlm + diasMeiosAlm + diaFdsAlm;
            vencimento_iliquido = diasCompletos + diasMeios + diasFds;
            bonus = ((saberBonus(arrayRH, posicao_func, horasTrabalhadas, saberDiaMax(conta->calculo_array[(conta->contador - num_salarios) + x].ano, conta->calculo_array[x].mes)) / 10) * vencimento_iliquido); 
            
            if( diasCompletosAlm > conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl * 4.99){ //e sujeito a imposto 
                vencimento_iliquido = vencimento_iliquido + (alimetacaoTotal - (conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl * 4.99));
                alimetacaoTotal = conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl * 4.99;
            } 
            
            vencimento_iliquido = vencimento_iliquido + bonus;
            
            SS_func = vencimento_iliquido * saberSS(1, arrayRH->funcionarios_array[posicao_func].codigo, arrayRH, taxa);
            SS_emp = vencimento_iliquido * saberSS(1, arrayRH->funcionarios_array[posicao_func].codigo, arrayRH, taxa);

            vencimento_liquido = (vencimento_iliquido + alimetacaoTotal) - (SS_func + IRS_func);
            
            //MOSTRAR CALCULOS FEITOS (SO PARA TESTES E VERIFICAÇÃO DAS CONTAS)
            printf("NORMAL: COMP: %f MEIOS: %f FDS: %f \n", diasCompletos, diasMeios, diasFds);
            printf("ALIMEN: COMP: %f MEIOS: %f FDS: %f \n", diasCompletosAlm, diasMeiosAlm, diaFdsAlm);
            printf("BONUS: %f \n", bonus);
            printf("SALARIO ILIQUIDO: %d \n", vencimento_iliquido);
            printf("SS FUNCIONARIO: %f \n", SS_func);
            printf("SS EMPRESA: %f \n", SS_emp);
            
            
            
            
            //PASSA O "PROCESSADO" PARA "1" (OU SEJA, JA ESA PROCESSADO)
            conta->calculo_array[(conta->contador - num_salarios) + x].proc = 1; // Ja foi processado
            
            //ADICIONA MEMORIA
            temp = (Calculo*) realloc(salarios->calculo_array, salarios->contador * sizeof(Calculo) + sizeof(Calculo));
            if (temp == NULL) {
                puts(ERRO_MEMORIA);
            }
            salarios->calculo_array = temp;
            temp = NULL;
            free(temp);
        }
    }
}

//FAZER CALCULO DO BONUS (TEM DE SER MELHORADO)
float saberBonus(Empresa *arrayRH, int posicao, int horasTrabalhadas, int dia_max){
    int tempoEmpresa, idade, horas_max;
    float bonus;
    
    tempoEmpresa = defineData(3) - arrayRH->funcionarios_array[posicao].entrada_emp.ano; //PODE SE TORNAR MAIS PRECISO
    idade = defineData(3) - arrayRH->funcionarios_array[posicao].nascimento.ano; //PODE SE TORNAR MAIS PRECISO
    horas_max = 8 * dia_max;
    
    bonus = ((horasTrabalhadas * tempoEmpresa * idade) / (TEMPO_MAXIMO * IDADE_MAXIMA * horas_max));

    return (bonus);
}