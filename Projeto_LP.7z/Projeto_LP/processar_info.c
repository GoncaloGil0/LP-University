//Bibliotecas
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//headers
#include "pedir_info.h"
#include "menus.h"
#include "processar_info.h"

int teste_process(){
    printf("Processos");

}

