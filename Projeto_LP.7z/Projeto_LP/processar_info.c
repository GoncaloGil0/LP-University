//Bibliotecas
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//headers
#include "pedir_info.h"
#include "ficheiros.h"
#include "menus.h"
#include "processar_info.h"

//SABER TAXA DA SS
float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa){
    
    if (entidade == 1) { // trabalhador
        
        switch (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].cargo){
            case 0: //empregado 
                return (taxa->geral_trabalhador);
                break;
            case 1: //chefe
                return (taxa->admin_trabalhador);
                break;
            case 2: //administrador
                return (taxa->admin_trabalhador);
                break;
            default:
                puts("ERRO");
        }
    } else { //entidade empregadora
        
        switch (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].cargo){
            case 0: //empregado 
                return (taxa->geral_empregadora);
                break;
            case 1: //chefe
                return (taxa->admin_empregadora);
                break;
            case 2: //administrador
                return (taxa->admin_empregadora);
                break;
            default:
                puts("ERRO");
        }
    }
}

//SABER TAXA DO IRS
float saberIRS(int vencimento, int codigo, Empresa *arrayRH, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado){
    int posicao = procurarFuncionario(arrayRH, codigo);
    
    if ( arrayRH->funcionarios_array[posicao].titulares == 1 ){ //unico titular
        for (int i=0 ; i<unico_titular->contador; i++){
            if ((unico_titular->Unico_titular_array[i].vencimento < vencimento && vencimento < unico_titular->Unico_titular_array[i+1].vencimento) || vencimento ==  unico_titular->Unico_titular_array[i+1].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (unico_titular->Unico_titular_array[i+1].filho_zero);
                        break;
                    case 1:
                        return (unico_titular->Unico_titular_array[i+1].filho_um);
                        break;
                    case 2:
                        return (unico_titular->Unico_titular_array[i+1].filho_dois);
                        break;
                    case 3:
                        return (unico_titular->Unico_titular_array[i+1].filho_tres);
                        break;
                    case 4:
                        return (unico_titular->Unico_titular_array[i+1].filho_quatro);
                        break;
                    default:
                        return (unico_titular->Unico_titular_array[i+1].filho_cinco);
                        break;
                }
                break;
            }
        }
    } else if (arrayRH->funcionarios_array[posicao].titulares == 2){ //dois titulares
        
        for (int i=0 ; i<dois_titulares->contador; i++){
            
            if ((dois_titulares->Dois_titulares_array[i].vencimento < vencimento && vencimento < dois_titulares->Dois_titulares_array[i+1].vencimento) || vencimento ==  dois_titulares->Dois_titulares_array[i+1].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (dois_titulares->Dois_titulares_array[i+1].filho_zero);
                        break;
                    case 1:
                        return (dois_titulares->Dois_titulares_array[i+1].filho_um);
                        break;
                    case 2:
                        return (dois_titulares->Dois_titulares_array[i+1].filho_dois);
                        break;
                    case 3:
                        return (dois_titulares->Dois_titulares_array[i+1].filho_tres);
                        break;
                    case 4:
                        return (dois_titulares->Dois_titulares_array[i+1].filho_quatro);
                        break;
                    default:
                        return (dois_titulares->Dois_titulares_array[i+1].filho_cinco);
                        break;
                }
            }
        }
    } else { //nao casado
        for (int i=0 ; i<nao_casado->contador; i++){
            
            if ((nao_casado->Nao_casado_array[i].vencimento < vencimento && vencimento < nao_casado->Nao_casado_array[i+1].vencimento) || vencimento ==  nao_casado->Nao_casado_array[i+1].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (nao_casado->Nao_casado_array[i+1].filho_zero);
                        break;
                    case 1:
                        return (nao_casado->Nao_casado_array[i+1].filho_um);
                        break;
                    case 2:
                        return (nao_casado->Nao_casado_array[i+1].filho_dois);
                        break;
                    case 3:
                        return (nao_casado->Nao_casado_array[i+1].filho_tres);
                        break;
                    case 4:
                        return (nao_casado->Nao_casado_array[i+1].filho_quatro);
                        break;
                    default:
                        return (nao_casado->Nao_casado_array[i+1].filho_cinco);
                        break;
                }
            }
        }
    }
}

//FAZER O CALCULO SALARIAL
void calcular(Lista_salarios *salarios, Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, int num_salarios){
    //APONTADORES
    Calculo *temp;
    FILE *ficheiro_relatorios;

    //VARIAVEIS
    char resposta;
    int n=0, x, opcao, posicaoFunc, horasTrabalhadas;
    float ValordiasCompletos, ValordiasMeios, ValordiasFds, ValordiasCompletosAlm, ValordiasMeiosAlm, ValordiaFdsAlm, ValoralimetacaoTotal, vencimentoIliquido, irs, SS_func, SS_emp, bonus, vencimentoLiquido;    

    do {
        printf("\n+ PROCESSAMENTO SALARIAL + \n");
        printf("| 1) Todos em memoria \n");
        printf("| 2) Só do/s ultimo/s adicionado/s \n");
        printf("| Opção: ");
        scanf("%d", &opcao);        
    }while (opcao < 1 || opcao > 2);

    if (opcao == 1){
        logs("PROCESSAMENTO SALARIAL (TODOS)");
        puts("|\n|+ SALARIOS CALCULADOS +");
        num_salarios = conta->contador;            

    } else if (opcao == 2) {
        logs("PROCESSAMENTO SALARIAL (ULTIMO)");
        puts(TITULO_SALARIOS_PROC);
        num_salarios = num_salarios;
    } 
   

    for(x=0; x != num_salarios; x++){
        
        if (conta->calculo_array[(conta->contador - num_salarios) + x].estado == 0){
            printf("codigo if1 : %d \n",conta->calculo_array[(conta->contador - num_salarios) + x].codigo);
            
            //SABER A POSIÇÃO DO FUNCIONARIO NA LISTA
            posicaoFunc = procurarFuncionario(arrayRH, conta->calculo_array[(conta->contador - num_salarios) + x].codigo);
            
            if (posicaoFunc != -1) {
                printf("codigo if2 : %d \n",conta->calculo_array[(conta->contador - num_salarios) + x].codigo);

                //CALCULO DAS HORAS TOTAIS TRABALHADAS
                horasTrabalhadas = ((8*conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl)+(4*conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios)+(8*conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds));

                //CALCULAR VENCIMENTO ILIQUIDO
                ValordiasCompletos = arrayRH->funcionarios_array[posicaoFunc].valor_hora * ( 8 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl);
                ValordiasMeios = arrayRH->funcionarios_array[posicaoFunc].valor_hora * ( 4 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios);
                ValordiasFds = (arrayRH->funcionarios_array[posicaoFunc].valor_hora * 1.5) * ( 8 * conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds); 

                ValordiasCompletosAlm = arrayRH->funcionarios_array[posicaoFunc].valor_sub_ali * conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl;
                ValordiasMeiosAlm = arrayRH->funcionarios_array[posicaoFunc].valor_sub_ali * conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios;
                ValordiaFdsAlm = (arrayRH->funcionarios_array[posicaoFunc].valor_sub_ali * 1.5) * conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds;

                ValoralimetacaoTotal = ValordiasCompletosAlm + ValordiasMeiosAlm + ValordiaFdsAlm;
                vencimentoIliquido = ValordiasCompletos + ValordiasMeios + ValordiasFds;
                bonus = vencimentoIliquido * saberBonus(arrayRH, conta, posicaoFunc, saberDiaMax(conta->calculo_array[(conta->contador - num_salarios) + x].ano, conta->calculo_array[(conta->contador - num_salarios)+x].mes), num_salarios, x); 
                vencimentoIliquido = vencimentoIliquido + bonus;
                
                //CALCULO DO IRS E SS
                SS_func = (vencimentoIliquido *  saberSS(1, arrayRH->funcionarios_array[posicaoFunc].codigo, arrayRH, taxa))/100;  
                SS_emp = (vencimentoIliquido * saberSS(0, arrayRH->funcionarios_array[posicaoFunc].codigo, arrayRH, taxa))/100;  
                irs = vencimentoIliquido * saberIRS(vencimentoIliquido, arrayRH->funcionarios_array[posicaoFunc].codigo , arrayRH, dois_titulares, unico_titular, nao_casado);

                vencimentoLiquido = (vencimentoIliquido + ValoralimetacaoTotal) - (SS_func + irs);

                //GUARDAR EM MEMORIA
                salarios->calculo_array[salarios->contador].codigo = arrayRH->funcionarios_array[posicaoFunc].codigo;
                salarios->calculo_array[salarios->contador].irs = irs;
                salarios->calculo_array[salarios->contador].ss_ent_patronal = SS_emp;
                salarios->calculo_array[salarios->contador].ss_ent_pessoal = SS_func;
                salarios->calculo_array[salarios->contador].sub_ali = ValoralimetacaoTotal;
                salarios->calculo_array[salarios->contador].venc_iliquido = vencimentoIliquido;
                salarios->calculo_array[salarios->contador].venc_liquido = vencimentoLiquido;
                salarios->calculo_array[salarios->contador].bonus = bonus;
                salarios->calculo_array[salarios->contador].encargo_total_emp = vencimentoIliquido + SS_emp;

                //PASSA O "PROCESSADO" PARA "1" (OU SEJA, JA ESTA PROCESSADO)
                conta->calculo_array[(conta->contador - num_salarios) + x].estado = 1;
                
                //ADICIONA MEMORIA PARA O PROXIMO CALCULO
                temp = (Calculo*) realloc(salarios->calculo_array, salarios->contador * sizeof(Calculo) + sizeof(Calculo));
                if (temp == NULL) {
                    puts(ERRO_MEMORIA);
                }
                salarios->calculo_array = temp;
                temp = NULL;
                free(temp);

                //ADICIONA NA CONTAGEM DE ELEMENTOS LIDOS
                n++;

                //ADICIONA RELATORIO DOC
                ficheiro_relatorios = fopen(FILENAME_RELATORIOS, "a");
                if (ficheiro_relatorios == NULL) {
                    puts(ERRO_FILE);
                } else {
                    fprintf(ficheiro_relatorios, FORMATO_GUARDAR_DOC_SALARIOS, 
                        arrayRH->funcionarios_array[posicaoFunc].nome, 
                        salarios->calculo_array[salarios->contador].codigo,
                        conta->calculo_array[(conta->contador - num_salarios) + x].mes,
                        conta->calculo_array[(conta->contador - num_salarios) + x].ano,
                        salarios->calculo_array[salarios->contador].venc_iliquido,
                        salarios->calculo_array[salarios->contador].bonus,
                        salarios->calculo_array[salarios->contador].sub_ali,
                        salarios->calculo_array[salarios->contador].ss_ent_patronal,
                        salarios->calculo_array[salarios->contador].ss_ent_pessoal,
                        salarios->calculo_array[salarios->contador].irs,
                        salarios->calculo_array[salarios->contador].venc_liquido,
                        salarios->calculo_array[salarios->contador].encargo_total_emp);
                }
                fclose(ficheiro_relatorios);

                //ADICIONA AO CONTADOR
                salarios->contador++;
                
            } else {
                printf(ERRO_DATABASE, conta->calculo_array[(conta->contador - num_salarios) + x].codigo);
            }
        }
    }
    
    if (n>0){
        
        if (n == 1){
            printf("| Foi processado 1 salario \n");
        } else if (n > 1){
            printf(INFO_SALARIOS_PROC, n);
        }
        
    
        do {
            printf(PERGUNTA_VER_SALARIOS, n);
            scanf(" %c", &resposta);
        } while (resposta != 'S' && resposta != 's' && resposta != 'N' && resposta != 'n');

        if (resposta == 's' || resposta == 'S'){

            for (int x=0; x < n; x++){
                printf(FORMATO_MOSTRAR_SALARIOS_TODOS, 
                        salarios->calculo_array[(salarios->contador - n) + x].codigo,
                        salarios->calculo_array[(salarios->contador - n) + x].venc_iliquido,
                        salarios->calculo_array[(salarios->contador - n) + x].bonus,
                        salarios->calculo_array[(salarios->contador - n) + x].sub_ali,
                        salarios->calculo_array[(salarios->contador - n) + x].ss_ent_patronal,
                        salarios->calculo_array[(salarios->contador - n) + x].ss_ent_pessoal,
                        salarios->calculo_array[(salarios->contador - n) + x].irs,
                        salarios->calculo_array[(salarios->contador - n) + x].venc_liquido,
                        salarios->calculo_array[(salarios->contador - n) + x].encargo_total_emp);
            }
        }
    } else if (n==0){
        printf(ERRO_NAO_SALARIOS);
    }  
}

//FAZER CALCULO DO BONUS (TEM DE SER MELHORADO)
float saberBonus(Empresa *arrayRH, Lista_calc *conta, int posicao, int dia_max, int num_salarios, int x) {
    float tempo, idade, dias, bonus;
    int dias_trab = conta->calculo_array[(conta->contador - num_salarios) + x].dias_compl + conta->calculo_array[(conta->contador - num_salarios) + x].dias_fds + conta->calculo_array[(conta->contador - num_salarios) + x].dias_meios;

    tempo = 0.53 * (defineData(3) - arrayRH->funcionarios_array[posicao].entrada_emp.ano);
    idade = 0.26 * ((defineData(3) - arrayRH->funcionarios_array[posicao].nascimento.ano) - 18);
    if ( dias_trab <= 22) {
        dias = 0;
    } else {
        dias = (12.5 / (dia_max - 22)) * (dias_trab - 22);
    }
    bonus = (tempo + idade + dias) / 100;
    return bonus;    
}