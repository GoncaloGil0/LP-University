//Bibliotecas
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

//headers
#include "pedir_info.h"
#include "menus.h"
#include "processar_info.h"
#include "ficheiros.h"

float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa){
    
    if (entidade == 1) { // trabalhador
        
        switch (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].cargo){
            case 0: //empregado 
                return (taxa->geral_trabalhador);
                break;
            case 1: //chefe
                return (taxa->admin_trabalhador);
                break;
            case 2: //administrador
                return (taxa->admin_trabalhador);
                break;
            default:
                puts("ERRO");
        }
    } else { //entidade empregadora
        
        switch (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].cargo){
            case 0: //empregado 
                return (taxa->geral_empregadora);
                break;
            case 1: //chefe
                return (taxa->admin_empregadora);
                break;
            case 2: //administrador
                return (taxa->admin_empregadora);
                break;
            default:
                puts("ERRO");
        }
    }
}

float saberIRS(int vencimento, int codigo, Empresa *arrayRH, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado){
    
    int posicao = procurarFuncionario(arrayRH, codigo);
    
    if ( arrayRH->funcionarios_array[posicao].titulares == 1 ){ //unico titular
        
        for (int i=0 ; i<unico_titular->contador; i++){
            
            if ((unico_titular->Unico_titular_array[i].vencimento < vencimento && vencimento < unico_titular->Unico_titular_array[i++].vencimento) || vencimento ==  unico_titular->Unico_titular_array[i].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (unico_titular->Unico_titular_array[i++].filho_zero);
                        break;
                    case 1:
                        return (unico_titular->Unico_titular_array[i++].filho_um);
                        break;
                    case 2:
                        return (unico_titular->Unico_titular_array[i++].filho_dois);
                        break;
                    case 3:
                        return (unico_titular->Unico_titular_array[i++].filho_tres);
                        break;
                    case 4:
                        return (unico_titular->Unico_titular_array[i++].filho_quatro);
                        break;
                    default:
                        return (unico_titular->Unico_titular_array[i++].filho_cinco);
                        break;
                }
                break;
            }
        }
    } else if (arrayRH->funcionarios_array[posicao].titulares == 2){ //dois titulares
        
        for (int i=0 ; i<dois_titulares->contador; i++){
            
            if ((dois_titulares->Dois_titulares_array[i].vencimento < vencimento && vencimento < dois_titulares->Dois_titulares_array[i++].vencimento) || vencimento ==  dois_titulares->Dois_titulares_array[i].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (dois_titulares->Dois_titulares_array[i++].filho_zero);
                        break;
                    case 1:
                        return (dois_titulares->Dois_titulares_array[i++].filho_um);
                        break;
                    case 2:
                        return (dois_titulares->Dois_titulares_array[i++].filho_dois);
                        break;
                    case 3:
                        return (dois_titulares->Dois_titulares_array[i++].filho_tres);
                        break;
                    case 4:
                        return (dois_titulares->Dois_titulares_array[i++].filho_quatro);
                        break;
                    default:
                        return (dois_titulares->Dois_titulares_array[i++].filho_cinco);
                        break;
                }
            }
        }
    } else { //nao casado
        for (int i=0 ; i<nao_casado->contador; i++){
            
            if ((nao_casado->Nao_casado_array[i].vencimento < vencimento && vencimento < nao_casado->Nao_casado_array[i++].vencimento) || vencimento ==  nao_casado->Nao_casado_array[i].vencimento){
                
                switch ( arrayRH->funcionarios_array[posicao].numero_filhos ){
                    case 0:
                        return (nao_casado->Nao_casado_array[i++].filho_zero);
                        break;
                    case 1:
                        return (nao_casado->Nao_casado_array[i++].filho_um);
                        break;
                    case 2:
                        return (nao_casado->Nao_casado_array[i++].filho_dois);
                        break;
                    case 3:
                        return (nao_casado->Nao_casado_array[i++].filho_tres);
                        break;
                    case 4:
                        return (nao_casado->Nao_casado_array[i++].filho_quatro);
                        break;
                    default:
                        return (nao_casado->Nao_casado_array[i++].filho_cinco);
                        break;
                }
            }
        }
    }
}
