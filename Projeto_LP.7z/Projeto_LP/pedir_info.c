#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>

#include "pedir_info.h"
#include "menus.h"
#include "ficheiros.h"
#include "processar_info.h"

//FUNÇOES
//SABER PARTES DA DATA 
int defineData(int pedido) {

    struct tm *data;
    time_t tempo;

    time(&tempo);
    data = localtime(&tempo);

    switch (pedido) {
        case 1:
            return (data->tm_mday); //retorna o dia caso receba o numero 1
        case 2:
            return (data->tm_mon + 1); // retorna o mes caso receba o numero 2
        case 3:
            return (data->tm_year + 1900); // retorna o ano caso receba o numero 3
        case 4:
            return (data->tm_hour); // retorna a hora caso receba o numero 4
        case 5:
            return (data->tm_min); // retorna o min caso receba o numero 5
        case 6:
            return (data->tm_sec); // // retorna o segundo caso receba o numero 6
    }
}
// SABER ANO
int saberAno(char *TEXTO) {
    int ano = obterInt(MIN_ANO, defineData(3), TEXTO);
    return ano;
}
// SABER MES
int saberMes(char *TEXTO, int ano) {
    int mes;
    if (ano == defineData(3)) {
        mes = obterInt(MIN_MES, defineData(2), TEXTO);
    } else {
        mes = obterInt(MIN_MES, MAX_MES, TEXTO);
    }

    return mes;
}
// SABER DIA
int saberDia(char *TEXTO, int ano, int mes) {
    return (obterInt(MIN_DIA, saberDiaMax(ano, mes), TEXTO));
}
// SABER DIA MAX
int saberDiaMax(int ano, int mes) {
    int dia;
    int meses[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if ((ano % 4) == 0) { //bissextos 
        if (ano == defineData(3) && mes == defineData(2)) {
            dia = defineData(1);
        } else if (ano == defineData(3) && mes != 2) {
            dia = meses[mes];
        } else if (ano == defineData(3) && mes == 2) {
            dia = meses[mes] + 1;
        } else if (ano != defineData(3) && mes == 2) {
            dia = meses[mes] + 1;
        } else if (ano != defineData(3) && mes != 2) {
            dia = meses[mes];
        }
    } else { // nao bissextos 
        if (ano == defineData(3) && mes == defineData(2)) {
            dia = defineData(1);
        } else if (ano == defineData(3) && mes != 2) {
            dia = meses[mes];
        } else if (ano == defineData(3) && mes == 2) {
            dia = meses[mes];
        } else if (ano != defineData(3) && mes == 2) {
            dia = meses[mes];
        } else if (ano != defineData(3) && mes != 2) {
            dia = meses[mes];
        }
    }
    return dia;
}
//CLEAN BUFFER
void cleanInputBuffer() {
    char ch;
    while ((ch = getchar()) != '\n' && ch != EOF);
}
//OBTER NUMEROS
int obterInt(int min, int max, char *texto) {
    int valor;
    printf(texto);
    while (scanf(" %d", &valor) != 1 || valor < min || valor > max) {
        puts(VALOR_INVALIDO);
        cleanInputBuffer();
        printf(texto);
    }
    cleanInputBuffer();
    return valor;
}
//OBTER STRINGS
void obterString(char *string, unsigned int tamanho, char *texto) {
    int invalido, i;
    unsigned int len;
    do {
        invalido = 0;
        printf(texto);
        if (fgets(string, tamanho, stdin) != NULL) {
            len = strlen(string) - 1;
            if (string[len] == '\n') {
                string[len] = '\0';
            }
            /*
            for (i = 0; i < len-1 ; i++) {
                if (isalpha(string[i]) == 0 && isspace(string[i]) == 0 ) {
                    puts(NOME_INVALIDO);
                    invalido = 1;
                    break;
                }
            }    
             */
        }
    } while (invalido == 1);
}
//OBTER LONG
long obterNum(long min, long max, char *texto) {
    long valor;
    printf(texto);
    while (scanf("%ld", &valor) != 1 || valor < min || valor > max) {
        puts(VALOR_INVALIDO);
        cleanInputBuffer();
        printf(texto);
    }
    cleanInputBuffer();
    return valor;
}
//CONVERSAO PARA STRING DO EST CIVIL
char *est_civilToString(Est_Civil tipo) {
    switch (tipo) {
        case CASADO:
            return "Casado";
            break;
        case SOLTEIRO:
            return "Solteiro";
            break;
        case DIVORCIADO:
            return "Divorciado";
            break;
        case VIUVO:
            return "Viúvo";
            break;
    }
}
//CONVERSAO PARA STRING DO CARGO
char *cargoToString(Cargo tipo) {
    switch (tipo) {
        case EMPREGADO:
            return "Empregado";
            break;
        case CHEFE:
            return "Chefe";
            break;
        case ADMINISTRADOR:
            return "Administrador";
            break;
    }
}

//ADICIONAR DO FUNCIONARIO
void addFuncionario(Empresa *arrayRH, int codigo) {
    
    //VARIAVEIS LOCAIS
    int est_civil, cargo, mes, ano, dia, titulares;
    char saida;
    double numero_tlm;
    Funcionario *temp;

    //ASSOCIAR CODIGO
    arrayRH->funcionarios_array[arrayRH->contador].codigo = codigo;


    //OBTER NOME
    obterString(arrayRH->funcionarios_array[arrayRH->contador].nome, MAX_NOME, OBTER_NOME);
    

    //OBTER NUMERO TELEMOVEL
    numero_tlm = obterNum(MIN_NUM_TELE, MAX_NUM_TELE, OBTER_NUM_TELE);
    arrayRH->funcionarios_array[arrayRH->contador].numero_tlm = numero_tlm;


    //OBTER ESTADO CIVIL
    do {
        printf(OBTER_EST_CIVIL);
        scanf("%d", &est_civil);
    } while (est_civil > 3 || est_civil < 0);
    arrayRH->funcionarios_array[arrayRH->contador].est_civil = est_civil;
    cleanInputBuffer();

    if (est_civil == 0) {
        do {
            printf(OBTER_TITULARES);
            scanf("%d", &titulares);
        } while (titulares < 1 || titulares > 2);
        arrayRH->funcionarios_array[arrayRH->contador].titulares = titulares;
    } else {
        arrayRH->funcionarios_array[arrayRH->contador].titulares = 0;
    }


    //OBTER NUMERO FILHOS
    printf(OBTER_NUM_FILHOS);
    scanf("%d", &arrayRH->funcionarios_array[arrayRH->contador].numero_filhos);
    cleanInputBuffer();



    //OBTER CARGO NA EMPRESA
    do {
        printf(OBTER_CARGO);
        scanf("%d", &cargo);
    } while (cargo > 2 || cargo < 0);
    arrayRH->funcionarios_array[arrayRH->contador].cargo = cargo;
    cleanInputBuffer();



    //OBTER SALARIO
    printf(OBTER_SALARIO);
    scanf("%f", &arrayRH->funcionarios_array[arrayRH->contador].valor_hora);
    cleanInputBuffer();



    //OBTER SUBSIDIO ALIMENTACAO
    printf(OBTER_SUB_ALI);
    scanf("%f", &arrayRH->funcionarios_array[arrayRH->contador].valor_sub_ali);
    cleanInputBuffer();


    //OBTER DATA NASCIMENTO
    puts(OBTER_DATA_NASC);

    ano = saberAno(OBTER_ANO);

    while ((defineData(3) - ano) < 18) {
        puts(DATA_IVALIDA_MENOR);
        ano = saberAno(OBTER_ANO);
    }

    if ((defineData(3) - ano) == 18) {
        do {
            mes = saberMes(OBTER_MES, ano);
        } while (mes > defineData(2));
    } else {
        mes = saberMes(OBTER_MES, ano);
    }

    if (((defineData(3) - ano) == 18) && (mes == defineData(2))) {
        do {
            dia = saberDia(OBTER_DIA, ano, mes);
        } while (dia > defineData(1));
    } else {
        dia = saberDia(OBTER_DIA, ano, mes);
    }

    arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano = ano;
    arrayRH->funcionarios_array[arrayRH->contador].nascimento.mes = mes;
    arrayRH->funcionarios_array[arrayRH->contador].nascimento.dia = dia;



    //OBTER DATA ENTRADA
    puts(OBTER_DATA_ENT);

    ano = saberAno(OBTER_ANO);

    while ((ano - arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano) < 18) {
        puts(DATA_IVALIDA_MENOR);
        ano = saberAno(OBTER_ANO);
    }

    if ((ano - arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano) == 18) {
        mes = saberMes(OBTER_MES, ano);
        while (mes > arrayRH->funcionarios_array[arrayRH->contador].nascimento.mes) {
            puts(DATA_IVALIDA_MENOR);
            mes = saberMes(OBTER_MES, ano);
        }
    } else {
        mes = saberMes(OBTER_MES, ano);
    }

    if (((ano - arrayRH->funcionarios_array[arrayRH->contador].nascimento.ano) == 18) && (mes == arrayRH->funcionarios_array[arrayRH->contador].nascimento.mes)) {
        dia = saberDia(OBTER_DIA, ano, mes);
        while (dia > arrayRH->funcionarios_array[arrayRH->contador].nascimento.dia) {
            puts(DATA_IVALIDA_MENOR);
            dia = saberDia(OBTER_DIA, ano, mes);
        }
    } else {
        dia = saberDia(OBTER_DIA, ano, mes);
    }

    arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano = ano;
    arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.mes = mes;
    arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.dia = dia;

    //VERIFICAR SE CONTINUA NA EMPRESA
    do {
        printf("| \n| Continua na empresa (s/n)? ");
        scanf(" %c", &saida);
    } while (saida != 'n' && saida != 's');
    cleanInputBuffer();


    //OBTER DATA SAIDA
    if (saida == 'n') {
        puts(OBTER_DATA_SAIDA);

        do {
            ano = saberAno(OBTER_ANO);
        } while (ano < arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano);

        if (ano == arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano) {
            do {
                mes = saberMes(OBTER_MES, ano);
            } while (mes < arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.mes);
        } else {
            mes = saberMes(OBTER_MES, ano);
        }

        if (ano == arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.ano && mes == arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.mes) {
            do {
                dia = saberDia(OBTER_DIA, ano, mes);
            } while (dia < arrayRH->funcionarios_array[arrayRH->contador].entrada_emp.dia);
        } else {
            dia = saberDia(OBTER_DIA, ano, mes);
        }

        arrayRH->funcionarios_array[arrayRH->contador].saida_emp.ano = ano;
        arrayRH->funcionarios_array[arrayRH->contador].saida_emp.mes = mes;
        arrayRH->funcionarios_array[arrayRH->contador].saida_emp.dia = dia;

    } else {

        arrayRH->funcionarios_array[arrayRH->contador].saida_emp.ano = 0;
        arrayRH->funcionarios_array[arrayRH->contador].saida_emp.mes = 0;
        arrayRH->funcionarios_array[arrayRH->contador].saida_emp.dia = 0;
    }


    //TORNAR FUNCIONARIO ATIVO
    arrayRH->funcionarios_array[arrayRH->contador].ativo = 1;


    //INCREMENTAR CONTADOR
    arrayRH->contador++;

    //INCREMENTAR MEMORIA
    temp = (Funcionario*) realloc(arrayRH->funcionarios_array, arrayRH->contador * sizeof (Funcionario) + sizeof (Funcionario));
    if (temp == NULL) {
        puts(ERRO_MEMORIA);
    }
    arrayRH->funcionarios_array = temp;
    temp = NULL;
    free(temp);
}
//PROCURAR FUNCIONARIO
int procurarFuncionario(Empresa *arrayRH, int codigo) {
    int i;
    for (i = 0; i < arrayRH->contador; i++) {
        if (arrayRH->funcionarios_array[i].codigo == codigo) {
            return i;
        }
    }
    return -1;
}
//VERIFICAR SE FUNCIONARIO JA EXISTE 
void verificacaoAddFuncionarios(Empresa *arrayRH) {
    while (1) {
        int codigo = obterInt(MIN_CODIGO, MAX_CODIGO, OBTER_CODIGO);
        if (procurarFuncionario(arrayRH, codigo) != -1) {
            printf(FUNC_EXISTENTE);
        } else {
            addFuncionario(arrayRH, codigo);
            break;
        }
    }
}
// FAZER A ALTERAÇAO DOS DADOS DO FUNCIONARIO 
void editarFuncionario(Empresa *arrayRH, int posicao, int opcao) {

    int est_civil, cargo, dia, mes, ano;
    double numero_tlm;
    char resposta;

    do {
        switch (opcao) {

            case 1:
                //ALTERAR TELEMOVEL
                numero_tlm = obterNum(MIN_NUM_TELE, MAX_NUM_TELE, OBTER_NUM_TELE);
                arrayRH->funcionarios_array[posicao].numero_tlm = numero_tlm;
                break;
            case 2:
                //ALTERAR ESTADO CIVIL
                do {
                    printf(OBTER_EST_CIVIL);
                    scanf("%d", &est_civil);
                } while (est_civil > 3 || est_civil < 0);
                arrayRH->funcionarios_array[posicao].est_civil = est_civil;
                cleanInputBuffer();
                break;
            case 3:
                // ALTERAR NUMERO DE FILHOS
                printf(OBTER_NUM_FILHOS);
                scanf("%d", &arrayRH->funcionarios_array[posicao].numero_filhos);
                cleanInputBuffer();
                break;
            case 4:
                // ALTERAR CARGO
                do {
                    printf(OBTER_CARGO);
                    scanf("%d", &cargo);
                } while (cargo > 2 || cargo < 0);
                arrayRH->funcionarios_array[posicao].cargo = cargo;
                cleanInputBuffer();
                break;
            case 5:
                // ALTERAR VALOR HORA
                printf(OBTER_SALARIO);
                scanf("%f", &arrayRH->funcionarios_array[posicao].valor_hora);
                cleanInputBuffer();
                break;
            case 6:
                // ALTERAR VALOR HORA ALIMENTACAO
                printf(OBTER_SUB_ALI);
                scanf("%f", &arrayRH->funcionarios_array[posicao].valor_sub_ali);
                cleanInputBuffer();
                break;
            case 7:
                // ALTERAR DATA DE SAIDA DA EMPRESA
                puts(OBTER_DATA_SAIDA);

                ano = saberAno(OBTER_ANO);
                mes = saberMes(OBTER_MES, ano);
                dia = saberDia(OBTER_DIA, ano, mes);

                arrayRH->funcionarios_array[posicao].saida_emp.ano = ano;
                arrayRH->funcionarios_array[posicao].saida_emp.mes = mes;
                arrayRH->funcionarios_array[posicao].saida_emp.dia = dia;
                break;
            case 0:
                // VOLTAR MENU DO FUNCIONARIO
                menu_gestao_funcionarios(arrayRH);
                break;
        }

        if (opcao != 0) {
            printf("|\n| Deseja fazer mais alterações [s/n]?");
            scanf(" %c", &resposta);

            if (resposta == 's') {
                printf("|\n| Digite o que quer editar: ");
                scanf("%d", &opcao);
            }
        } else {
            break;
        }

    } while (resposta == 's');
}
// MOSTRAR OS DADOS DO FUNCIONARIO 
int infoFuncionario(Empresa *arrayRH, int posicao) {

    int opcao;

    printf("%s%s\n", OBTER_NOME, arrayRH->funcionarios_array[posicao].nome);
    printf("%s%ld\n", OBTER_NUM_TELE, arrayRH->funcionarios_array[posicao].numero_tlm);
    printf("%s%s\n", EST_CIVIL, est_civilToString(arrayRH->funcionarios_array[posicao].est_civil));
    printf("%s%d\n", OBTER_NUM_FILHOS, arrayRH->funcionarios_array[posicao].numero_filhos);
    printf("%s%s\n", CARGO, cargoToString(arrayRH->funcionarios_array[posicao].cargo));
    printf("%s%.2f euros\n", OBTER_SALARIO, arrayRH->funcionarios_array[posicao].valor_hora);
    printf("%s%.2f euros\n", OBTER_SUB_ALI, arrayRH->funcionarios_array[posicao].valor_sub_ali);
    printf("%s%d.%d.%d\n", OBTER_DATA_NASC, arrayRH->funcionarios_array[posicao].nascimento.dia, arrayRH->funcionarios_array[posicao].nascimento.mes, arrayRH->funcionarios_array[posicao].nascimento.ano);
    printf("%s%d-%d-%d\n", OBTER_DATA_ENT, arrayRH->funcionarios_array[posicao].entrada_emp.dia, arrayRH->funcionarios_array[posicao].entrada_emp.mes, arrayRH->funcionarios_array[posicao].entrada_emp.ano);

    if (arrayRH->funcionarios_array[posicao].saida_emp.dia != 0) { // se o funcionario ja nao estiver na empresa
        printf("%s%d-%d-%d\n", OBTER_DATA_SAIDA, arrayRH->funcionarios_array[posicao].saida_emp.dia, arrayRH->funcionarios_array[posicao].saida_emp.mes, arrayRH->funcionarios_array[posicao].saida_emp.ano);
    }

    do {
        puts("\n| Escolha o parametro que deseja alterar:");
        puts("| 1) Numero de telemovel");
        puts("| 2) Estado Civil");
        puts("| 3) Numero de filhos");
        puts("| 4) Cargo");
        puts("| 5) Valor hora");
        puts("| 6) Valor hora subsidio de alimentação");
        puts("| 7) Data de saida da empresa");
        puts("| 0) Voltar");
        printf("| Opção: ");
        scanf("%d", &opcao);

    } while (opcao < 0 || opcao > 7);

    editarFuncionario(arrayRH, posicao, opcao);

    return (opcao);

}
//VERIFICAR SE PODE EDITAR FUNCIONARIO
void verificacaoEditarFuncionarios(Empresa *arrayRH) {
    char resposta;
    int codigo = obterInt(MIN_CODIGO, MAX_CODIGO, OBTER_CODIGO);
    int posicao = procurarFuncionario(arrayRH, codigo);
    if (posicao != -1 && arrayRH->funcionarios_array[posicao].ativo == 1) {
        infoFuncionario(arrayRH, posicao);
    } else if (posicao != -1 && arrayRH->funcionarios_array[posicao].ativo != 1) {
        printf("| !Funcionário inacessível!\n");
        do {
            printf("| Deseja adicionar um funcionário [s/n]?");
            scanf(" %c", &resposta);
        } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');
        if (resposta == 's' || resposta == 'S') {
            verificacaoAddFuncionarios(arrayRH);
        }
    } else {
        puts(FUNC_INEXISTENTE);
        do {
            printf("| Deseja adicionar um funcionário com esse codigo [s/n]?");
            scanf(" %c", &resposta);
        } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');
        if (resposta == 's' || resposta == 'S') {
            cleanInputBuffer();
            addFuncionario(arrayRH, codigo);
        }
    }
}
//REMOVER FUNCIONARIOS
void removerFuncionario(Empresa *arrayRH) {
    int i = procurarFuncionario(arrayRH, obterInt(MIN_CODIGO, MAX_CODIGO, OBTER_CODIGO));
    if (i != -1 && arrayRH->funcionarios_array[i].ativo == 1) {
        arrayRH->funcionarios_array[i].ativo = 0;
        puts(SUCESSO);
    } else if (i != -1 && arrayRH->funcionarios_array[i].ativo == 0) {
        printf("| !Funcionário já removido!\n");
    } else {
        puts(FUNC_INEXISTENTE);
    }
}

//VERIFICAR SOMA DOS DIAS
int verificacaoDias(int dias_compl, int dias_meios, int dias_fds, int dias_faltas, int mes, int ano) {

    if ((dias_compl + dias_meios + dias_fds + dias_faltas) > saberDiaMax(ano, mes)) {
        puts(DIAS_MAIOR_MES);
        return 1;
    }
    if ((dias_compl + dias_meios + dias_fds + dias_faltas) < saberDiaMax(ano, mes)) {
        puts(DIAS_FALTA_MES);
        return 1;
    }
}
//CALCULAR SALARIOS
void calcSalarial(Lista_calc *conta, int codigo, Empresa *arrayRH, Taxas *taxa, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado, Lista_salarios *salarios) {
    char resposta;
    
    int ano, mes, dias_compl, dias_meios, dias_fds, dias_faltas,ano_saida, mes_saida, dia_saida;
    Conta *temp;
    
    if (arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].saida_emp.ano == 0){
        ano_saida =defineData(3);
        mes_saida =defineData(2);
        dia_saida =defineData(1);
    } else {
        ano_saida = arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].saida_emp.ano;
        mes_saida = arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].saida_emp.mes;
        dia_saida = arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].saida_emp.dia;
    }
    puts(TITLE_CALC);
        
    ano = saberAno(OBTER_NUM_ANO); 
    while (ano < arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].entrada_emp.ano || ano > ano_saida) {
        printf(DATA_INVALIDA_SALARIO, "ANO");
        ano = saberAno(OBTER_NUM_ANO); 
    }

    mes = saberMes(OBTER_NUM_MES, ano);
    if (ano == ano_saida){
        while (mes > mes_saida){
            printf(DATA_INVALIDA_SALARIO, "MES");
            mes = saberMes(OBTER_NUM_MES, ano);
        }
    } else if (ano == arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].entrada_emp.ano) {
        while (mes < arrayRH->funcionarios_array[procurarFuncionario(arrayRH, codigo)].entrada_emp.mes){
            printf(DATA_INVALIDA_SALARIO, "MES");
            mes = saberMes(OBTER_NUM_MES, ano);
        }
    }
    
    do {
        dias_compl = obterInt(MIN_DIAS_TRABALHO, saberDiaMax(ano, mes), OBTER_DIAS_COMPL);
        dias_meios = obterInt(MIN_DIAS_TRABALHO, saberDiaMax(ano, mes) - dias_compl, OBTER_DIAS_MEIOS);
        dias_fds = obterInt(MIN_DIAS_TRABALHO, 10, OBTER_DIAS_FDS);
        dias_faltas = obterInt(MIN_DIAS_TRABALHO, saberDiaMax(ano, mes) - (dias_compl+dias_meios+dias_fds), OBTER_DIAS_FALTAS);
    } while (verificacaoDias(dias_compl, dias_meios, dias_fds, dias_faltas, mes, ano) == 1);
    
    conta->calculo_array[conta->contador].codigo = codigo;
    conta->calculo_array[conta->contador].ano = ano;
    conta->calculo_array[conta->contador].mes = mes;
    conta->calculo_array[conta->contador].dias_compl = dias_compl;
    conta->calculo_array[conta->contador].dias_meios = dias_meios;
    conta->calculo_array[conta->contador].dias_fds = dias_fds;
    conta->calculo_array[conta->contador].dias_faltas = dias_faltas;
    conta->calculo_array[conta->contador].proc = 0;
    
    puts(SUCESSO);
    (conta->contador)++;
    temp = (Conta*) realloc(conta->calculo_array, conta->contador * sizeof (Conta) + sizeof (Conta));
    if (temp == NULL) {
        puts(ERRO_MEMORIA);
    }
    conta->calculo_array = temp;
    temp = NULL;
    free(temp);
        
    do {
        printf("| Deseja fazer o processamento salarial [s/n]? ");
        scanf(" %c", &resposta);        
    }while (resposta != 's' && resposta != 'S' && resposta != 'N' && resposta != 'n');
    
    if (resposta == 'S' || resposta == 's'){
        calcular(salarios, arrayRH, conta, taxa, dois_titulares, unico_titular, nao_casado, 1);
    }
}
//VERIFICAR EXISTENCIA DO FUNCIONARIO PARA CALCULO
void verificacaoFuncionariosCalculo(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres, Lista_salarios *salarios) {
    char resposta;
    int codigo = obterInt(MIN_CODIGO, MAX_CODIGO, OBTER_CODIGO);
    if (procurarFuncionario(arrayRH, codigo) != -1) {
        calcSalarial(conta, codigo, arrayRH, taxa, array_um, array_dois, array_tres, salarios);
    } else {
        puts(FUNC_INEXISTENTE);
        do {
            printf("\n| Deseja adicionar o funcionário com esse codigo [s/n]?");
            scanf(" %c", &resposta);
        } while (resposta != 's' && resposta != 'n' && resposta != 'S' && resposta != 'N');
        if (resposta == 's' || resposta == 'S') {
            addFuncionario(arrayRH, codigo);
        }
    }
}
