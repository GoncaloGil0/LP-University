#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "menus.h"
#include "ficheiros.h"
//#include "processar_info.h"

int main() {
    
    //VARIAVEIS
    Empresa RH;
    RH.contador = 0;
    RH.funcionarios_array = NULL;
    
    Lista_calc conta;
    conta.contador = 0;
    conta.calculo_array = NULL;
    
    Lista_um lista_um;
    lista_um.contador = 0;
    lista_um.Dois_titulares_array = NULL;
    
    Lista_dois lista_dois;
    lista_dois.contador = 0;
    lista_dois.Unico_titular_array = NULL;
    
    Lista_tres lista_tres;
    lista_tres.contador = 0;
    lista_tres.Nao_casado_array = NULL;
   
    char resposta;
    
    printf ("| INFORMAÇÕES DO SISTEMA: \n");
    printf ("| Numero de users em memoria: %d \n", importar_users_sys(&RH));
    printf ("| Numero de salarios em memoria: %d \n", importar_salarios_sys(&conta));
    printf ("| Tabela 1: ");
    importarTabela_um(&lista_um);
    printf ("| Tabela 2: ");
    importarTabela_dois(&lista_dois);
    printf ("| Tabela 3: ");
    importarTabela_tres(&lista_tres);
    
    printf ("\n");
        
    //CHAMAR MENU
    do {
        menu(&RH, &conta);
        puts("");
        
        printf("+ Deseja continuar no programa [s/n]? ");
        scanf(" %c", &resposta);
        puts("");
        
        //guardar(&RH, &conta, &lista_um, &lista_dois, &lista_tres);
        
    } while (resposta != 'n');

        
    return (0);
}
