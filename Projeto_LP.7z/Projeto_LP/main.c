#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "menus.h"
#include "ficheiros.h"
#include "processar_info.h"

int main() {
    
    //VARIAVEIS
    Empresa RH;
    RH.contador = 0;
    RH.funcionarios_array = (Funcionario*) malloc (sizeof (Funcionario));
    if (RH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    Lista_calc conta;
    conta.contador = 0;
    conta.calculo_array = (Conta*) malloc (sizeof (Conta));
    if (RH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    ListaUm lista_um;
    lista_um.contador = 0;
    lista_um.Dois_titulares_array = (Dois_titulares*) malloc (sizeof(Dois_titulares));
    if (RH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    ListaDois lista_dois;
    lista_dois.contador = 0;
    lista_dois.Unico_titular_array = (Unico_titular*) malloc (sizeof(Unico_titular));
    if (RH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    ListaTres lista_tres;
    lista_tres.contador = 0;
    lista_tres.Nao_casado_array = (Nao_casado*) malloc (sizeof(Nao_casado));
    if (RH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    Taxas taxa;
   
    char resposta;
    
    printf("| INFORMAÇÕES DO SISTEMA: \n");
    printf("| Numero de users em memoria: %d \n", importar_users_sys(&RH));
    printf("| Numero de salarios em memoria: %d \n", importar_salarios_sys(&conta));
    printf("| Tabela IRS 1: ");
    importarTabela_um(&lista_um);
    printf("| Tabela IRS 2: ");
    importarTabela_dois(&lista_dois);
    printf("| Tabela IRS 3: ");
    importarTabela_tres(&lista_tres);
    printf("| Tabela SS: ");
    importarTablelaSS(&taxa);
    
    printf ("\n\n");
        
    //CHAMAR MENU
    do {
        menu(&RH, &conta, &taxa, &lista_um, &lista_dois, &lista_tres);
        puts("");
        
        printf("+ Deseja continuar no programa [s/n]? ");
        scanf(" %c", &resposta);
        puts("");      
        
    } while (resposta != 'n' && resposta != 'N');
    
    printf("+ Deseja guardar os dados? ");
    scanf(" %c", &resposta);
    
    if ( resposta == 'S' || resposta == 's') {
        logs("SAIR E GUARDAR");
        printf("\n");
        guardar(&RH, &conta, &lista_um, &lista_dois, &lista_tres, &taxa); 
    } else {
       logs("SAIR SEM GUARDAR");
    }
    
    
    return (0);
}
