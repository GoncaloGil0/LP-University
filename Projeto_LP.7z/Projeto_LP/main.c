#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "ficheiros.h"
#include "processar_info.h"
#include "menus.h"


int main() {
    
    
    //VARIAVEIS E MEMORIAS DINAMICAS 
    Empresa arrayRH;
    arrayRH.contador = 0;
    arrayRH.funcionarios_array = (Funcionario*) malloc (sizeof (Funcionario));
    if (arrayRH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    Lista_calc conta;
    conta.contador = 0;
    conta.calculo_array = (Conta*) malloc (sizeof (Conta));
    if (arrayRH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    DoisTitulares dois_titulares;
    dois_titulares.contador = 0;
    dois_titulares.Dois_titulares_array = (IRS*) malloc (sizeof(IRS));
    if (arrayRH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    UnicoTitular unico_titular;
    unico_titular.contador = 0;
    unico_titular.Unico_titular_array = (IRS*) malloc (sizeof(IRS));
    if (arrayRH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    NaoCasado nao_casado;
    nao_casado.contador = 0;
    nao_casado.Nao_casado_array = (IRS*) malloc (sizeof(IRS));
    if (arrayRH.funcionarios_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    Lista_salarios salarios;
    salarios.contador = 0;
    salarios.calculo_array = (Calculo*) malloc (sizeof(Calculo));
    if (salarios.calculo_array == NULL) {
        puts(ERRO_MEMORIA);
    }
    
    Taxas taxa;
   
    char resposta;
    
    printf("| INFORMAÇÕES DO SISTEMA: \n");
    printf("| Numero de users em memoria: %d \n", importar_users_sys(&arrayRH));
    printf("| Numero de salarios em memoria: %d \n", importar_salarios_sys(&conta));
    printf("| Numero de salarios processados em memoria: %d \n", importar_salarios_proc_sys(&salarios));
    printf("| Tabela IRS 1: ");
    importarDoisTitulares(&dois_titulares);
    printf("| Tabela IRS 2: ");
    importarUnicoTitular(&unico_titular);
    printf("| Tabela IRS 3: ");
    importarNaoCasado(&nao_casado);
    printf("| Tabela SS: ");
    importarTablelaSS(&taxa);
    
    printf("\n\n");
        
    //CHAMAR MENU
    do {
        menu(&arrayRH, &conta, &taxa, &dois_titulares, &unico_titular, &nao_casado, &salarios);
        puts("");
        
        printf("+ Deseja continuar no programa [s/n]? ");
        scanf(" %c", &resposta);
        puts("");

    } while (resposta != 'n' && resposta != 'N');
    
    printf("+ Deseja guardar os dados [s/n]? ");
    scanf(" %c", &resposta);
    
    if ( resposta == 'S' || resposta == 's') {
        logs("SAIR E GUARDAR");
        printf("\n");
        guardar(&arrayRH, &conta, &dois_titulares, &unico_titular, &nao_casado, &taxa, &salarios); 
        printf("\n+ A aplicação foi terminada com sucesso");

    } else {
        logs("SAIR SEM GUARDAR");
        printf("\n+ A aplicação foi terminada com sucesso");

    }
    
    
    return (0);
}
