
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "menus.h"
#include "ficheiros.h"

//MENU PRINCIPAL
void menu(Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres) {

    int opcao;

    do {
        printf("+ MENU + \n");
        printf("| 1) Cálculo salarial\n");
        printf("| 2) Gestão de funcionarios\n");
        printf("| 3) Gestão das tabelas de descontos para o IRS\n");
        printf("| 4) Gestão das taxas da segurança social\n");
        printf("| 5) Listagens \n");
        printf("| 6) Guardar todos os dados em memoria\n");
        printf("| 0) Sair\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 6);

    switch (opcao) {

        case 1:
            menu_calc_salarial(conta, arrayRH);
            break;
        case 2:
            menu_gestao_funcionarios(arrayRH);
            break;
        case 3:
            menu_gestao_tabelas_IRS(array_um, array_dois, array_tres);
            break;
        case 4:
            menu_gestao_SS(taxa);
            break;
        case 5:
            menu_listagens();
            break;
        case 6:
            logs("GUARDAR INFORMAÇÃO");
            guardar(arrayRH, conta, array_um, array_dois, array_tres, taxa);
            break;
        case 0:
            logs("SAIR");
            guardar(arrayRH, conta, array_um, array_dois, array_tres, taxa);
            printf("\n+ A aplicação foi terminada com sucesso");
            exit(0);
    }
}

//MENU MANUAL OU FICHEIRO CALCULO SALARIAL
void menu_calc_salarial(Lista_calc *conta, Empresa *arrayRH) {
    int opcao;

    do {
        printf("\n+ INTRODUÇÃO DE DADOS PARA CÁLCULO SALARIAL +\n");
        printf("| 1) Manualmente\n");
        printf("| 2) Ficheiro\n");
        printf("| 3) Ver todos \n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 4);

    switch (opcao) {
        case 1:
            logs("CALCULO SALARIAL (Manual)");
            puts("\n+ CALCULO SALARIAL +");
            verificacaoFuncionariosCalculo(conta, arrayRH);
            break;
        case 2:
            logs("CALCULO SALARIAL (Ficheiro)");
            importar_salarios_doc(conta);
            break;
        case 3:
            logs("TODOS OS SALARIOS");
            puts("\n+ TODOS OS SALARIOS +");
            mostrarSalarios(conta);
        case 0:
            break;
    }
}

//MENU MANUAL OU FICHEIRO FUNCIONARIO
void menu_tipo_add_funcionarios(Empresa *arrayRH) {
    int opcao;

    do {
        printf("\n+ ADICIONAR FUNCIONARIO  +\n");
        printf("| 1) Manualmente\n");
        printf("| 2) Ficheiro\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 4);

    switch (opcao) {
        case 1:
            logs("ADICIONAR FUNCIONARIO (Manual)");
            puts("\n+ DADOS FUNCIONARIO +");
            verificacaoAddFuncionarios(arrayRH);
            break;
        case 2:
            logs("ADICIONAR FUNCIONARIO (Ficheiro)");
            importar_users_doc(arrayRH);
            break;
        case 0:
            break;
    }
}

//MENU FUNCIONARIOS MANUAL
void menu_gestao_funcionarios(Empresa *arrayRH) {

    int opcao;

    do {
        printf("\n+ GESTÃO DE FUNCIONARIOS +\n");
        printf("| 1) Adicionar\n");
        printf("| 2) Editar\n");
        printf("| 3) Remover\n");
        printf("| 4) Ver todos\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 5);

    switch (opcao) {
        case 1:
            menu_tipo_add_funcionarios(arrayRH);
            break;
        case 2:
            logs("EDITAR FUNCIONARIO ");
            puts("\n+ EDITAR FUNCIONARIO +");
            verificacaoEditarFuncionarios(arrayRH);
            break;
        case 3:
            logs("REMOVER FUNCIONARIO ");
            puts("\n+ REMOVER FUNCIONARIO +");
            removerFuncionario(arrayRH);
            break;
        case 4:
            logs("VER TODOS FUNCIONARIOS");
            puts("\n+ TODOS OS FUNCIONARIOS +");
            mostrarUsers(arrayRH);
        case 0:
            break;
    }
}

//MENU TABELAS
void menu_gestao_tabelas_IRS(ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres) {

    int opcao;

    do {
        printf("\n+ GESTÃO DAS TABELAS DE DESCONTOS PARA O IRS +\n");
        printf("| 1) Alterar criterio\n");
        printf("| 2) Mostrar tabelas\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 3);


    switch (opcao) {
        case 1:
            logs("ALTERAR CRITERIO IRS");
            puts("\n+ ALTERAR CRITERIO +");
            alterarCriterioIRS(array_um, array_dois, array_tres);
            break;
        case 2:
            logs("MOSTRAR TABELAS IRS");
            puts("\n+ MOSTRAR TABELAS +");
            mostratTabelas(array_um, array_dois, array_tres);
            break;
        case 0:
            break;
    }
}

//MENU TAXAS IRS
void menu_gestao_SS(Taxas *taxa) {

    int opcao;

    do {
        printf("\n+ GESTÃO DAS TAXAS DA SEGURANÇA SOCIAL +\n");
        printf("| 1) Alterar Criterio\n");
        printf("| 2) Mostrar todas as taxas\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 3);


    switch (opcao) {
        case 1:
            logs("ALTERAR CRITERIO SS");
            puts("\n+ ALTERAR CRITERIO +");
            alterarCriterioSS(taxa );
            break;
        case 2:
            logs("MOSTRAR TODAS AS TAXAS");
            puts("\n+ MOSTRAR TODAS AS TAXAS +");
            mostrarTaxas(taxa);
            break;
        case 0:
            break;
    }
}

//MENU LISTAGENS
void menu_listagens() {

    int opcao;

    do {
        printf("\n+ MENU LISTAGENS +\n");
        printf("| 1) Listagem 1\n");
        printf("| 2) Listagem 2\n");
        printf("| 3) Listagem 3\n");
        printf("| 4) Listagem 4\n");
        printf("| 5) Listagem 5\n");
        printf("| 0) Voltar\n");
        printf("| Opçãoo: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 5);

    switch (opcao) {
        case 1:
            //listagem 1  //mostrar ativos
            break;
        case 2:
            //listagem 2  //mostar total de salarios (gasto geral em salarios)
            break;
        case 3:
            //listagem 3     //mostar total de impostos (gasto geral em impostos)
            break;
        case 4:
            //listagem 4    //mostar codigos de users removidos
            break;
        case 5:
            //listagem 5    //mostrar % de assiduidade
            break;
        case 0:
            break;
    }

}

//MOSTRAR TODOS OS USERS
void mostrarUsers(Empresa *arrayRH) {

    for (int x = 0; x < arrayRH->contador; x++) {
        if (arrayRH->funcionarios_array[x].ativo == 1) {
            printf(FORMATO_MOSTRAR_TODOS_USERS, arrayRH->funcionarios_array[x].codigo,
                    arrayRH->funcionarios_array[x].nome,
                    arrayRH->funcionarios_array[x].numero_tlm,
                    est_civilToString(arrayRH->funcionarios_array[x].est_civil),
                    arrayRH->funcionarios_array[x].titulares,
                    arrayRH->funcionarios_array[x].numero_filhos,
                    cargoToString(arrayRH->funcionarios_array[x].cargo),
                    arrayRH->funcionarios_array[x].valor_hora,
                    arrayRH->funcionarios_array[x].valor_sub_ali,
                    arrayRH->funcionarios_array[x].nascimento.dia,
                    arrayRH->funcionarios_array[x].nascimento.mes,
                    arrayRH->funcionarios_array[x].nascimento.ano,
                    arrayRH->funcionarios_array[x].entrada_emp.dia,
                    arrayRH->funcionarios_array[x].entrada_emp.mes,
                    arrayRH->funcionarios_array[x].entrada_emp.ano,
                    arrayRH->funcionarios_array[x].saida_emp.dia,
                    arrayRH->funcionarios_array[x].saida_emp.mes,
                    arrayRH->funcionarios_array[x].saida_emp.ano);
            printf("\n");
        }
    }
}

//MOSTRAR TODOS OS SALARIOS
void mostrarSalarios(Lista_calc *conta) {

    for (int x = 0; x < conta->contador; x++) {
        printf(FORMATO_MOSTRAR_TODOS_SALARIOS, conta->calculo_array[x].codigo,
                conta->calculo_array[x].ano,
                conta->calculo_array[x].mes,
                conta->calculo_array[x].dias_compl,
                conta->calculo_array[x].dias_meios,
                conta->calculo_array[x].dias_fds,
                conta->calculo_array[x].dias_faltas);
    }
}