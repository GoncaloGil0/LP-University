#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pedir_info.h"
#include "ficheiros.h"
#include "processar_info.h"
#include "menus.h"

//MENU PRINCIPAL

void menu(Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios) {

    int opcao;
    char resposta;

    do {
        printf("+ MENU + \n");
        printf("| 1) Cálculo salarial\n");
        printf("| 2) Gestão de funcionarios\n");
        printf("| 3) Gestão das tabelas de descontos para o IRS\n");
        printf("| 4) Gestão das taxas da segurança social\n");
        printf("| 5) Listagens \n");
        printf("| 6) Guardar dados em memoria\n");
        printf("| 7) Apagar dados em memoria\n");
        printf("| 0) Sair\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 7);

    switch (opcao) {

        case 1:
            menu_calc_salarial(conta, arrayRH, taxa, dois_titulares, unico_titular, nao_casado, salarios);
            break;
        case 2:
            menu_gestao_funcionarios(arrayRH);
            break;
        case 3:
            menu_gestao_tabelas_IRS(dois_titulares, unico_titular, nao_casado);
            break;
        case 4:
            menu_gestao_SS(taxa);
            break;
        case 5:
            menu_listagens(arrayRH, salarios, conta);
            break;
        case 6:
            logs("GUARDAR INFORMAÇÃO");
            puts("");
            guardar(arrayRH, conta, dois_titulares, unico_titular, nao_casado, taxa, salarios);
            break;
        case 7:
            do {
                printf("| Esta função vai obriga-lo a sair do programa, deseja continuar [s/n]? ");
                scanf(" %c", &resposta);
            } while (resposta != 'S' && resposta != 's' && resposta != 'N' && resposta != 'n');

            if (resposta == 'S' || resposta == 's') {
                limpar_memoria();
                exit(0);
            }
            break;

        case 0:
            do {
                printf("\n+ Deseja guardar os dados? ");
                scanf(" %c", &resposta);
            } while (resposta != 'S' && resposta != 's' && resposta != 'N' && resposta != 'n');

            if (resposta == 'S' || resposta == 's') {
                logs("SAIR E GUARDAR");
                printf("\n");
                guardar(arrayRH, conta, dois_titulares, unico_titular, nao_casado, taxa, salarios);
            } else {
                logs("SAIR SEM GUARDAR");
            }

            printf("\n+ A aplicação foi terminada com sucesso");
            exit(0);
    }
}

//MENU MANUAL OU FICHEIRO CALCULO SALARIAL

void menu_calc_salarial(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios) {
    int opcao;

    do {
        printf("\n+ CÁLCULO SALARIAL +\n");
        printf("| 1) Introduzir dados\n");
        printf("| 2) Ver salarios (por processar e processados)\n");
        printf("| 3) Fazer o calculo salarial \n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 3);

    switch (opcao) {
        case 1:
            menu_add_salarios(conta, arrayRH, taxa, dois_titulares, unico_titular, nao_casado, salarios);
            break;
        case 2:
            menu_mostrar_salarios(conta, salarios);
            break;
        case 3:
            logs("FAZER CALCULO DE TODOS OS SALARIOS");
            calcular(salarios, arrayRH, conta, taxa, dois_titulares, unico_titular, nao_casado, conta->contador);
            break;
        case 0:
            break;
    }
}

//MENU MOSTRAR SALARIOS

void menu_mostrar_salarios(Lista_calc *conta, Lista_salarios *salarios) {
    int opcao;
    do {
        printf("\n+ CÁLCULO SALARIAL +\n");
        printf("| 1) Ver todos os salarios por processar\n");
        printf("| 2) Ver todos os salarios processados \n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 2);

    switch (opcao) {
        case 1:
            logs("MOSTRAR SALARIOS POR PROCESSAR");
            puts("\n+ SALARIOS POR PROCESSAR +");
            if (conta->contador == 0) {
                printf("\n+ Não existem salarios para processar +\n");
            } else {
                for (int x = 0; x < conta->contador; x++) {
                    if (conta->calculo_array[x].estado != 1) {
                        printf(FORMATO_MOSTRAR_SALARIOS, conta->calculo_array[x].codigo,
                                conta->calculo_array[x].ano,
                                conta->calculo_array[x].mes,
                                conta->calculo_array[x].dias_compl,
                                conta->calculo_array[x].dias_meios,
                                conta->calculo_array[x].dias_fds,
                                conta->calculo_array[x].dias_faltas,
                                estadoToString(conta->calculo_array[x].estado));
                    }
                }
            }
            break;
        case 2:
            logs("MOSTRAR TODOS OS SALARIOS PROCESSADOS");
            puts("\n+ SALARIOS PROCESSADOS +");
            if (salarios->contador == 0) {
                puts("\n+ Nao existem salarios processados +");
            } else {
                for (int x = 0; x < salarios->contador; x++) {
                    printf(FORMATO_MOSTRAR_SALARIOS_TODOS,
                            salarios->calculo_array[x].codigo,
                            salarios->calculo_array[x].venc_iliquido,
                            salarios->calculo_array[x].bonus,
                            salarios->calculo_array[x].sub_ali,
                            salarios->calculo_array[x].ss_ent_patronal,
                            salarios->calculo_array[x].ss_ent_pessoal,
                            salarios->calculo_array[x].irs,
                            salarios->calculo_array[x].venc_liquido,
                            salarios->calculo_array[x].encargo_total_emp);
                }
            }
            break;
        case 0:
            break;
    }
}

//MENU ADICIONAR DADOS SALARIOS

void menu_add_salarios(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios) {
    int opcao;

    do {
        printf("\n+ INTRODUZIR DADOS PARA O CALCULO SALARIAL +\n");
        printf("| 1) Manualmente\n");
        printf("| 2) Ficheiro\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 2);

    switch (opcao) {
        case 1:
            logs("CALCULO SALARIAL (Manual)");
            puts("\n+ CALCULO SALARIAL +");
            verificacaoFuncionariosCalculo(conta, arrayRH, taxa, dois_titulares, unico_titular, nao_casado, salarios);
            break;
        case 2:
            logs("CALCULO SALARIAL (Ficheiro)");
            importar_salarios_doc(conta, arrayRH, taxa, dois_titulares, unico_titular, nao_casado, salarios);
            break;
        case 0:
            break;
    }
}

//MENU MANUAL OU FICHEIRO FUNCIONARIO

void menu_tipo_add_funcionarios(Empresa *arrayRH) {
    int opcao;

    do {
        printf("\n+ ADICIONAR FUNCIONARIO  +\n");
        printf("| 1) Manualmente\n");
        printf("| 2) Ficheiro\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 4);

    switch (opcao) {
        case 1:
            logs("ADICIONAR FUNCIONARIO (Manual)");
            puts("\n+ DADOS FUNCIONARIO +");
            verificacaoAddFuncionarios(arrayRH);
            break;
        case 2:
            logs("ADICIONAR FUNCIONARIO (Ficheiro)");
            importar_users_doc(arrayRH);
            break;
        case 0:
            break;
    }
}

//MENU FUNCIONARIOS MANUAL

void menu_gestao_funcionarios(Empresa *arrayRH) {

    int opcao;

    do {
        printf("\n+ GESTÃO DE FUNCIONARIOS +\n");
        printf("| 1) Adicionar\n");
        printf("| 2) Editar\n");
        printf("| 3) Remover\n");
        printf("| 4) Ver todos\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 5);

    switch (opcao) {
        case 1:
            menu_tipo_add_funcionarios(arrayRH);
            break;
        case 2:
            logs("EDITAR FUNCIONARIO ");
            puts("\n+ EDITAR FUNCIONARIO +");
            verificacaoEditarFuncionarios(arrayRH);
            break;
        case 3:
            logs("REMOVER FUNCIONARIO ");
            puts("\n+ REMOVER FUNCIONARIO +");
            removerFuncionario(arrayRH);
            break;
        case 4:
            logs("VER TODOS FUNCIONARIOS");
            puts("\n+ TODOS OS FUNCIONARIOS +");
            mostrarUsers(arrayRH);
        case 0:
            break;
    }
}

//MENU TABELAS

void menu_gestao_tabelas_IRS(DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado) {

    int opcao;

    do {
        printf("\n+ GESTÃO DAS TABELAS DE DESCONTOS PARA O IRS +\n");
        printf("| 1) Alterar criterio\n");
        printf("| 2) Mostrar tabelas\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 3);


    switch (opcao) {
        case 1:
            logs("ALTERAR CRITERIO IRS");
            puts("\n+ ALTERAR CRITERIO +");
            alterarCriterioIRS(dois_titulares, unico_titular, nao_casado);
            break;
        case 2:
            logs("MOSTRAR TABELAS IRS");
            puts("\n+ MOSTRAR TABELAS +");
            mostratTabelas(dois_titulares, unico_titular, nao_casado);
            break;
        case 0:
            break;
    }
}

//MENU TAXAS IRS

void menu_gestao_SS(Taxas *taxa) {

    int opcao;

    do {
        printf("\n+ GESTÃO DAS TAXAS DA SEGURANÇA SOCIAL +\n");
        printf("| 1) Alterar Criterio\n");
        printf("| 2) Mostrar todas as taxas\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 3);


    switch (opcao) {
        case 1:
            logs("ALTERAR CRITERIO SS");
            puts("\n+ ALTERAR CRITERIO +");
            alterarCriterioSS(taxa);
            break;
        case 2:
            logs("MOSTRAR TODAS AS TAXAS");
            puts("\n+ MOSTRAR TODAS AS TAXAS +");
            mostrarTaxas(taxa);
            break;
        case 0:
            break;
    }
}

//MENU LISTAGENS

void menu_listagens(Empresa *arrayRH, Lista_salarios *salarios, Lista_calc *conta) {
    float soma = 0, n = 0;
    char buffer[250];
    int opcao, escolha;

    do {
        printf("\n+ MENU LISTAGENS +\n");
        printf("| 1) Mostrar ex funcionarios\n");
        printf("| 2) Total gasto pela empresa \n");
        printf("| 3) Total gasto pela empresa em impotos\n");
        printf("| 4) Mostrar funcionarios removidos\n");
        printf("| 5) Criar ficheiros\n");
        printf("| 0) Voltar\n");
        printf("| Opção: ");
        scanf("%d", &opcao);
    } while (opcao < 0 || opcao > 5);

    switch (opcao) {
        case 1:
            logs("LISTAGEM DE EX FUNCIONARIOS");

            if (arrayRH->contador == 0) {
                puts("| Não foram adicionados funcionarios");
            } else {
                printf("\n+ LISTAGEM DE EX FUNCIONARIOS +");
                for (int i = 0; i < arrayRH->contador; i++) {
                    if (arrayRH->funcionarios_array[i].saida_emp.ano != 0) {
                        printf("\n| Código %d ", arrayRH->funcionarios_array[i].codigo);
                    }
                    n++;
                }
            }
            if (n == 0) {
                puts("\n+ Não exitem funcionarios fora da empresa");
            }

            break;
        case 2:
            logs("TOTAL GASTO PELA EMPRESA");
            if (salarios->contador == 0) {
                puts("| Não foram processados salarios");
            } else {
                for (int x = 0; x < salarios->contador; x++) {
                    soma = soma + salarios->calculo_array[x].encargo_total_emp;
                }
                printf("\n+ GASTO PELA EMPRESA: %0.2f +", soma);
            }
            break;
        case 3:
            logs("TOTAL GASTO PELA EMPRESA EM IMPOSTOS");
            if (salarios->contador == 0) {
                puts("| Não foram processados salarios");
            } else {
                for (int x = 0; x < salarios->contador; x++) {
                    soma = soma + salarios->calculo_array[x].ss_ent_patronal;
                }
                printf("\n+ GASTO PELA EMPRESA EM IMPOSTOS: %0.2f +", soma);
            }
            break;
        case 4:
            logs("LISTAGEM DE FUNCIONARIOS REMOVIDOS");
            if (arrayRH->contador == 0) {
                puts("+ Não foram adicionados funcionarios");
            } else {
                printf("\n+ LISTAGEM DE FUNCIONARIOS REMOVIDOS +");
                for (int i = 0; i < arrayRH->contador; i++) {
                    if (arrayRH->funcionarios_array[i].ativo == 0) {
                        printf("\n| Código %d ", arrayRH->funcionarios_array[i].codigo);
                        n++;
                    }
                }
            }
            if (n == 0) {
                puts("\n+ Não exitem funcionarios removidos");
            }
            break;
        case 5:
            criarFicheirosUser(arrayRH, conta, salarios);
            break;
        case 0:
            break;
    }
}

//MOSTRAR TODOS OS USERS

void mostrarUsers(Empresa *arrayRH) {
    if (arrayRH->contador == 0) {
        printf("\n+ Não existem utilizadores +");
    } else {
        for (int x = 0; x < arrayRH->contador; x++) {
            if (arrayRH->funcionarios_array[x].ativo == 1) {
                printf(FORMATO_MOSTRAR_USERS, arrayRH->funcionarios_array[x].codigo,
                        arrayRH->funcionarios_array[x].nome,
                        arrayRH->funcionarios_array[x].numero_tlm,
                        est_civilToString(arrayRH->funcionarios_array[x].est_civil),
                        arrayRH->funcionarios_array[x].titulares,
                        arrayRH->funcionarios_array[x].numero_filhos,
                        estadoToString(arrayRH->funcionarios_array[x].cargo),
                        arrayRH->funcionarios_array[x].valor_hora,
                        arrayRH->funcionarios_array[x].valor_sub_ali,
                        arrayRH->funcionarios_array[x].nascimento.dia,
                        arrayRH->funcionarios_array[x].nascimento.mes,
                        arrayRH->funcionarios_array[x].nascimento.ano,
                        arrayRH->funcionarios_array[x].entrada_emp.dia,
                        arrayRH->funcionarios_array[x].entrada_emp.mes,
                        arrayRH->funcionarios_array[x].entrada_emp.ano,
                        arrayRH->funcionarios_array[x].saida_emp.dia,
                        arrayRH->funcionarios_array[x].saida_emp.mes,
                        arrayRH->funcionarios_array[x].saida_emp.ano);
            }
        }
    }
}
