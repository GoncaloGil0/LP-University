#ifndef PROCESSAR_INFO_H
#define PROCESSAR_INFO_H

#include "ficheiros.h"

//REGISTOS

//CALCULO
typedef struct{ 
    int venc_liquido;
    float venc_iliquido, encargo_total_emp, iva, sub_ali, bonus, ss_ent_patronal, ss_ent_pessoal;
} Calculo;

float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa);
float saberIRS(int vencimento, int codigo, Empresa *arrayRH, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado);

#endif /* PROCESSAR_INFO_H */


