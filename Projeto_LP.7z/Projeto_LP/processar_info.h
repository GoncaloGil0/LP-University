#ifndef PROCESSAR_INFO_H
#define PROCESSAR_INFO_H

//CONSTANTES 
#define TEMPO_MAXIMO 47
#define IDADE_MAXIMA 65

#define VALOR_SA 4.77

#define FORMATO_MOSTRAR_SALARIOS_TODOS "\n+VENCIMENTO+\n| Codigo: %d \n| Vencimento iliquido: %0.1f \n| Bonus: %0.1f \n| Sub. Alimentação: %0.1f \n| Segurança Social Entidade patronal: %0.1f \n| Segurança Social Entidade pessoal: %0.1f \n| IRS: %0.1f \n| Vencimento Liquido: %0.1f\n| Encargo Total da empresa: %0.1f \n\n"
#define FORMATO_GUARDAR_DOC_SALARIOS "\n+VENCIMENTO+\n| Nome: %s \n| Codigo: %d \n| Data: %d/%d \n| Vencimento iliquido: %0.1f \n| Bonus: %0.1f \n| Sub. Alimentação: %0.1f \n| Segurança Social Entidade patronal: %0.1f \n| Segurança Social Entidade pessoal: %0.1f \n| IRS: %0.1f \n| Vencimento Liquido: %0.1f\n| Encargo Total da empresa: %0.1f \n\n"

#define FILENAME_RELATORIOS "UTILIZADOR\\RELATORIOS\\RELATORIO.txt"

float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa);
float saberIRS(int vencimento, int codigo, Empresa *arrayRH, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado);
void calcular(Lista_salarios *salarios, Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado, int num_salarios);
float saberBonus(Empresa *arrayRH, Lista_calc *conta, int posicao, int dia_max, int num_salarios, int x);

#endif /* PROCESSAR_INFO_H */


