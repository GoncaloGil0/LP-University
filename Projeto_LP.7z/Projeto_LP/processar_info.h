#ifndef PROCESSAR_INFO_H
#define PROCESSAR_INFO_H

#include "ficheiros.h"

//CONSTANTES 
#define TEMPO_MAXIMO 3
#define IDADE_MAXIMA 3

//REGISTOS

//CALCULO
typedef struct{ 
    int venc_liquido, codigo;
    float venc_iliquido, encargo_total_emp, iva, sub_ali, bonus, ss_ent_patronal, ss_ent_pessoal;
} Calculo;

typedef struct{ 
    int contador;
    Calculo *calculo_array;
} Lista_salarios;

float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa);
float saberIRS(int vencimento, int codigo, Empresa *arrayRH, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado);
void calcular(Lista_salarios *salarios, Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, ListaUm *dois_titulares, ListaDois *unico_titular, ListaTres *nao_casado, int num_salarios);
float saberBonus(Empresa *arrayRH, int posicao, int horasTrabalhadas, int dia_max);

#endif /* PROCESSAR_INFO_H */


