#ifndef PROCESSAR_INFO_H
#define PROCESSAR_INFO_H

//CONSTANTES 
#define TEMPO_MAXIMO 47
#define IDADE_MAXIMA 65

//FORMATOS DE TEXTO
#define FORMATO_MOSTRAR_SALARIOS_TODOS "\n+VENCIMENTO+\n| Codigo: %d \n| Vencimento iliquido: %0.1f \n| Bonus: %0.1f \n| Sub. Alimentação: %0.1f \n| Segurança Social Entidade patronal: %0.1f \n| Segurança Social Entidade pessoal: %0.1f \n| IRS: %0.1f \n| Vencimento Liquido: %0.1f\n| Encargo Total da empresa: %0.1f \n\n"
#define FORMATO_GUARDAR_DOC_SALARIOS "\n+VENCIMENTO+\n| Nome: %s \n| Codigo: %d \n| Data: %d/%d \n| Vencimento iliquido: %0.1f \n| Bonus: %0.1f \n| Sub. Alimentação: %0.1f \n| Segurança Social Entidade patronal: %0.1f \n| Segurança Social Entidade pessoal: %0.1f \n| IRS: %0.1f \n| Vencimento Liquido: %0.1f\n| Encargo Total da empresa: %0.1f \n\n"

//FICHEIROS
#define FILENAME_RELATORIOS "UTILIZADOR\\RELATORIOS\\RELATORIO.txt"

//PERGUNTAS
#define PERGUNTA_VER_SALARIOS "| Deseja ver todos os %d salarios processados [s/n]? "

//INFORMAÇÃO
#define TITULO_SALARIOS_PROC "|\n|+ SALARIOS CALCULADOS +"

//MENSAGENS (ERRO OU SUCESSO)
#define ERRO_DATABASE "| O Codigo nº %d não se encontra no database \n"
#define ERRO_NAO_SALARIOS "| Não existem salarios para processar \n"
#define INFO_SALARIOS_PROC "| Foram processados %d salarios \n"

//FUNÇÕES
float saberSS(int entidade, int codigo, Empresa *arrayRH, Taxas *taxa);
float saberIRS(int vencimento, int codigo, Empresa *arrayRH, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado);
void calcular(Lista_salarios *salarios, Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, int num_salarios);
float saberBonus(Empresa *arrayRH, Lista_calc *conta, int posicao, int dia_max, int num_salarios, int x);

#endif /* PROCESSAR_INFO_H */


