#ifndef PROCESSAR_INFO_H
#define PROCESSAR_INFO_H

//REGISTOS

//CALCULO
typedef struct{ 
    int venc_liquido;
    float venc_iliquido, encargo_total_emp, iva, sub_ali, bonus, ss_ent_patronal, ss_ent_pessoal;
} Calculo;


int teste_process();

#endif /* PROCESSAR_INFO_H */

