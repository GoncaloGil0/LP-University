#ifndef MENUS_H
#define MENUS_H

//MENUS
void menu(Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres, Lista_salarios *salarios);
void menu_calc_salarial(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres, Lista_salarios *salarios);
void menu_tipo_add_funcionarios( Empresa *arrayRH );
void menu_gestao_funcionarios(Empresa *arrayRH);
void menu_gestao_tabelas_IRS(ListaUm *array_um, ListaDois *array_dois, ListaTres *array_tres);
void menu_gestao_SS(Taxas *taxa );
void menu_listagens(Empresa *arrayRH, Lista_salarios *salarios, Lista_calc *conta);

//MOSTRAR
void mostrarUsers(Empresa *arrayRH);
void mostrarSalarios(Lista_calc *conta);

#endif
