#ifndef MENUS_H
#define MENUS_H

#define FORMATO_MOSTRAR_TODOS_USERS "\n+ FUNCIONARIO +\n| Codigo: %d \n| Nome: %s \n| Numero de telemovel: %ld \n| Estado civil: %s \n| Numero de titulares: %d \n| Numero de filhos: %d \n| Cargo: %s \n| Valor hora: %f \n| Subsidio de alimentação: %f \n| Data de nascimento: %d-%d-%d \n| Data de entrada na empresa: %d-%d-%d \n| Data de saida da empresa: %d-%d-%d\n"
#define FORMATO_MOSTRAR_TODOS_SALARIOS "\n| %d | %d | %d | %d | %d | %d | %d"

//FUNÇOES

//MENUS
int menu(Empresa *arrayRH, Lista_calc *conta);
int menu_calc_salarial ( Lista_calc *conta , Empresa *arrayRH);
int menu_tipo_add_funcionarios( Empresa *arrayRH );
int menu_gestao_funcionarios(Empresa *arrayRH);
int menu_gestao_tabelas();
int menu_listagens();

//MENU TABELAS 
//void add_criterio();
//void criar_criterio();

//LISTAGENS
//void print_listagem();

//MOSTRAR
void mostrarUsers(Empresa *arrayRH);
void mostrarSalarios(Lista_calc *conta);

#endif
