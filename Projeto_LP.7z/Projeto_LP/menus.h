#ifndef MENUS_H
#define MENUS_H

//MENUS
void menu(Empresa *arrayRH, Lista_calc *conta, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios);
void menu_calc_salarial(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios);
void menu_tipo_add_funcionarios( Empresa *arrayRH );
void menu_gestao_funcionarios(Empresa *arrayRH);
void menu_gestao_tabelas_IRS(DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *array_tres);
void menu_gestao_SS(Taxas *taxa );
void menu_listagens(Empresa *arrayRH, Lista_salarios *salarios, Lista_calc *conta);
void menu_mostrar_salarios(Lista_calc *conta, Lista_salarios *salarios);
void menu_add_salarios(Lista_calc *conta, Empresa *arrayRH, Taxas *taxa, DoisTitulares *dois_titulares, UnicoTitular *unico_titular, NaoCasado *nao_casado, Lista_salarios *salarios);

//MOSTRAR
void mostrarUsers(Empresa *arrayRH);

#endif
